package de.wnck.hhn.gvs.sso.communication.mock;

public interface BDUser2SSOViaMockMBean {
	void setCommunicationProblem();
	void setWorkingMode();

}
