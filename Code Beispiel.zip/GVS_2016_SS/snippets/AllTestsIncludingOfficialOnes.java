package de.wnck.hhn.gvs.sso.service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import de.hhn.seb.gvs.sso.tests.AllTests;


@RunWith(Suite.class)
@SuiteClasses({ SimpleSSOTest.class, AllTests.class })
public class AllTestsIncludingOfficialOnes {

}
