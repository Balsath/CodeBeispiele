package de.wnck.hhn.gvs.sso.service;

import java.util.logging.Logger;

import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.wnck.hhn.gvs.sso.communication.rmi.BDUser2SSOViaRmi;

public class SimpleBDUser2SSOTestClient {

	/** Testattribut. */
	private static String NICKNAME = "hugilein";
	/** Standardlogger. */
	private static Logger logger = Logger.getLogger(SimpleBDUser2SSOTestClient.class.getName());

	/**
	 * @param args
	 *            Command line parameters.
	 * @throws Exception
	 *             For everything that may go wrong.
	 */
	public static final void main(final String[] args) throws Exception {
		// Hier Ihren Stub instantiieren, wie der auch immer in ihrem Implementierungsprojekt heisst ...
		BDUser2SSO user2sso = new BDUser2SSOViaRmi();
		String name = "hugo2";
		String passwort = "geheim, sehr geheim";
		String email = "hugo@geheim.de";
		String hostname = "127.0.0.1";
		String port = "" + 1099;
		logger.info("Setze Parameter für Hostname/Port: " + hostname + "/" + port);
		user2sso.setParameter("hostname", hostname);
		user2sso.setParameter("portnumber", port);
		logger.info("Registriere USER mit name/passwort/email: " + name + "/" + passwort + "/" + email);
		user2sso.register(name, passwort, email);
		logger.info("Melde mich an mit name/passwort: " + name + "/" + passwort);
		Token token = user2sso.login(name, passwort);
		logger.info("Melde mich ab mit Token: " + token);
		user2sso.addAttribute(token, User.NICK_NAME, NICKNAME);
		User user = user2sso.getAllAttributes(token);
		String nickname = user.getAttribute(User.NICK_NAME);
		if (NICKNAME.equals(nickname)) {
			logger.info("Adding Attribute worked well.");
		} else {
			logger.severe(">>>>>  Failure in adding an attribute!");
		}

		user2sso.logout(token);
		logger.info("Das wars.");
	}

}
