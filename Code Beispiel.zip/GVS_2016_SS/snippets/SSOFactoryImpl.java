/**
 * 
 */
package de.wnck.hhn.gvs.sso.tests;

import java.util.logging.Logger;

import de.hhn.seb.gvs.sso.service.Admin2SSO;
import de.hhn.seb.gvs.sso.service.Service2SSO;
import de.hhn.seb.gvs.sso.service.User2SSO;
import de.hhn.seb.gvs.sso.tests.SSOFactory;
import de.wnck.hhn.gvs.sso.service.SSO;

/**
 * @author wnck
 *
 */
public class SSOFactoryImpl implements SSOFactory {
	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(SSOFactoryImpl.class.getName());

	/** Reference to the actual SSO implementation object. */
	private SSO sso;

	/**
	 * Default constructor. Needed for instantiation mechanism for
	 * FactoryFactory using "getClassByName" and then "getInstance".
	 */
	public SSOFactoryImpl() {
	}

	private SSO nonNullSSO() {
		if (sso == null) {
			sso = new SSO();
		}
		return sso;
	}

	@Override
	public final User2SSO getUser2SSO() {
		return nonNullSSO();
	}


	@Override
	public final Service2SSO getService2SSO() {
		return nonNullSSO();
	}

	@Override
	public final Admin2SSO getAdmin2SSO() {
		return nonNullSSO();
	}

	@Override
	public final void resetServer() {
		sso = null;
	}
}
