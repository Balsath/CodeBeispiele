package simple.shapes;

public abstract class GraphicalObject {

}
