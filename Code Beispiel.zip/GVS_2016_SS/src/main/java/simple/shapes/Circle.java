package simple.shapes;

import java.io.Serializable;
import java.util.logging.Logger;

/**
 * Simple Circle class for demonstration purpose
 */
public class Circle extends GraphicalObject implements Serializable{
	private static Logger logger = Logger.getLogger(Circle.class.getName());
	/**
	 * 
	 */
	private static final long serialVersionUID = 8084990708075378109L;
	private int radius;

	public Circle(int radius) {
		this.radius = radius;
		logger.info("Create new circle with radius " + radius);
	}

	
	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}


	public static void main(String[] args) {
		System.out.println("Circle Test");
		Circle circle = new Circle(12);
		System.out.println("Circle is " + circle);
	}

}
