package de.hhn.seb.gvs.sso.shared.communicate.sockets;

import de.hhn.seb.gvs.sso.shared.basics.Token;


public class LogoutRequest extends Request {
	private Token token;

	/**
	 * @param token
	 */
	public LogoutRequest(Token token) {
		super();
		this.token = token;
	}

	public Token getToken() {
		return token;
	}
	
	
	
}
