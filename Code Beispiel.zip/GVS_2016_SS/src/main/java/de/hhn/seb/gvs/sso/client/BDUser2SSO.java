package de.hhn.seb.gvs.sso.client;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

/**
 * Business Delegate interface to the User2SSO interface of the SSO
 * implementation. This interface has two goals:
 * <ul>
 * <li>Since all distribution related exceptions are mapped onto the
 * ServiceNotAvailableException the communication component implementing this
 * interface can easily substituted with another component using a different
 * distribution technology.
 * <li>There is a simple way to transfer connection parameters, gathered through
 * the user interface, into the communication component.
 * 
 * </ul>
 * 
 * All methods with a very similar method in User2SSO will just reference to the
 * javadoc to be found there.
 * 
 * Important: The ServiceNotAvailableException summons ALL distribution problems.
 * 
 * @author wnck
 * 
 */
public interface BDUser2SSO {

	/**
	 * @throws InvalidParameterException 
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#logout(Token)
	 */
	void logout(Token token) throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#login(String, String)
	 */
	Token login(String username, String password) throws InvalidParameterException, ServiceNotAvailableException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#register(String, String, String)
	 */
	void register(String username, String password, String emailAddress)
			throws NameAlreadyAssignedException, InvalidParameterException, ServiceNotAvailableException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#addAttribute(Token, String, String)
	 */
	void addAttribute(final Token token, final String key, final String value)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#removeAttribute(Token, String)
	 */
	void removeAttribute(final Token token, final String key)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException;

	/**
	 * @throws InvalidParameterException 
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#getAllAttributes(Token)
	 */
	User getAllAttributes(final Token token) throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException;

	/**
	 * Getter for supported parameters.
	 * 
	 * @param key
	 *            name of the parameter
	 * @return value of the parameter if the parameter is set, otherwise null.
	 * @throws ParameterNotSupportedException
	 *             if the parameter is not supported by the Implementation of
	 *             this interface.
	 */
	String getParameter(final String key) throws ParameterNotSupportedException;

	/**
	 * Allows the user interface to pass configuration parameters to the
	 * implementing class. In case of the socket implementation this may be host
	 * name or IP address and the port number of the SSO server. In case of Java
	 * RMI this would be the host name or IP address and the port number of the
	 * rmiregistry. In case of a REST-Service this may be an URL-String.
	 * 
	 * @param key
	 *            key of the parameter
	 * @param value
	 *            value of the parameter
	 * @throws ParameterNotSupportedException
	 *             when the given key is not known by the implementation.
	 * @throws InvalidParameterException
	 *             if key or value are null references or the key is no readable
	 *             string.
	 */
	void setParameter(final String key, final String value)
			throws ParameterNotSupportedException, InvalidParameterException;

}
