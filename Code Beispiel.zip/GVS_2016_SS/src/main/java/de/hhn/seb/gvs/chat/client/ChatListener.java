package de.hhn.seb.gvs.chat.client;

import de.hhn.seb.gvs.chat.shared.basics.Comment;

/**
 * Interface of a client component, either a ClientChatModel or a GUI component,
 * which has the task to visualize incoming chat messages. This interface
 * decouples the communication part (BDChatService, ...) from the GUI
 * technology.
 * 
 * @author wnck
 * 
 */
public interface ChatListener {
	/**
	 * forwards a "comment" to an interested component, e.g. the GUI part of the
	 * client or a client chat model.
	 * 
	 * @param comment
	 */
	void showComment(Comment comment);
}
