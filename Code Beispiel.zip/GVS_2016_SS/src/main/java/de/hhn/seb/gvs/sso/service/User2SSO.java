package de.hhn.seb.gvs.sso.service;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

/**
 * Interface of a user client to communicate with the SSO implementation. This
 * interface allows the registration of the user as well as login and logout.
 * Additionally the user can set and remove attributes in the SSO service which
 * may partially passed to requesting services like the chat service or a
 * fast poll service.
 * 
 * @author wnck
 * 
 */
public interface User2SSO {
	/** Minimal password length. */
	static final int MIN_PASSWORD_LENGTH = 8;

	/**
	 * Logs the user out of the SSO. The Token gets invalid, also for requests
	 * of other services like a chat server.
	 * 
	 * @param token
	 *            Token object created at login time.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 * @throws InvalidParameterException
	 *             if the token is not correct, not a token of this server or a
	 *             null reference.
	 */
	void logout(Token token) throws InvalidTokenException, InvalidParameterException;

	/**
	 * Log a user in into the SSO server. The user may login several times
	 * without logout. In this case the user gets always the same (identical)
	 * token object.
	 * 
	 * @param username
	 *            user name used while registering
	 * @param password
	 *            users password
	 * @return Token Token representing the user, kind of temporal passport.
	 * @throws InvalidParameterException
	 *             if any parameter is not valid.
	 */
	Token login(String username, String password)
			throws InvalidParameterException;

	/**
	 * registers a new user. It is not possible to "deregister".
	 * 
	 * @param username
	 *            user name, which is not case sensitive. The user name has to
	 *            be unique within an SSO server.
	 * @param password
	 *            password of the user. The password may never get outside of
	 *            the SSO server. The password must have at minimum MIN_PASSWORD_LENGTH
	 *            characters after password.trim().
	 * @param emailAddress
	 *            email address of the user. It must be checked if this can be a
	 *            real email address (syntax).
	 * @throws NameAlreadyAssignedException
	 *             if the user name is already assigned to another user.
	 * @throws InvalidParameterException
	 *             If one of the parameters is not valid.
	 */
	void register(String username, String password, String emailAddress)
			throws NameAlreadyAssignedException, InvalidParameterException;

	/**
	 * Adds an attribute to the hashmap.
	 * 
	 * @param token
	 *            token of the user
	 * @param key
	 *            unique key of the attribute. Could be one of the constants of
	 *            the User class or any other key. If the attribute is already
	 *            known it gets overwritten.
	 * @param value
	 *            user specific value
	 * @throws InvalidParameterException
	 *             when the key is no readable string or
	 *             if the token is not correct, not a token of this server or a
	 *             null reference.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 */
	void addAttribute(final Token token, final String key, final String value)
			throws InvalidParameterException, InvalidTokenException;

	/**
	 * removes an attribute.
	 * 
	 * @param token
	 *            token of the user
	 * @param key
	 *            key of attribute to be removed.
	 * @throws InvalidParameterException
	 *             when the key is no readable string or
	 *             if the token is not correct, not a token of this server or a
	 *             null reference.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 */
	void removeAttribute(final Token token, final String key)
			throws InvalidParameterException, InvalidTokenException;

	/**
	 * Returns a User object containing all attributes the SSO knows of.
	 * 
	 * @param token
	 *            token of the user
	 * @return User object containing all attributes of the user but the
	 *         password.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 * @throws InvalidParameterException
	 *             if the token is not correct, not a token of this server or a
	 *             null reference.
	 */
	User getAllAttributes(final Token token) throws InvalidParameterException, InvalidTokenException;
}
