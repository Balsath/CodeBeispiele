package de.hhn.seb.gvs.sso.shared.communicate.sockets;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.logging.Logger;

public abstract class Message implements Serializable {

	protected int id;
	protected static int idcounter;
	protected Date send;

	static transient Logger logger = Logger.getLogger(Message.class.getName());

	/**
	 * Konstruktor weist der Nachricht eine eindeutige Nummer zu.
	 */
	public Message() {
		super();
		id = ++idcounter;
	}

	public Date getSend() {
		return send;
	}

	/**
	 * Schreibt die Message auf einen ObjectOutputStream heraus. Dabei wird ein Zeitstempel in die
	 * Nachricht aufgenommen. Die Message wird durch den Aufruf von out.flush() gleich versendet.
	 * 
	 * @param out Ausgabestrom, auf den die Message geschrieben werden soll.
	 * @throws IOException
	 */
	public void sendOnStream(ObjectOutputStream out) throws IOException {
		this.send = new Date();
		out.writeObject(this);
		out.flush();
		logger.finer("Message written and flushed.");
	}

	/**
	 * Getter f�r die ID der Message. *
	 * 
	 * @return Message-ID
	 */
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		String retval = "[Message] ";
		retval += "id = " + id;
		return retval;
	}

}
