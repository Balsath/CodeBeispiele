package de.hhn.seb.gvs.sso.shared.exceptions;

/**
 * The NameAlreadyAssignedException indicates that a certain name is already in
 * use and thus cannot be used in this operation.
 * 
 * @author wnck
 *
 */
@SuppressWarnings("serial")
public class NameAlreadyAssignedException extends Exception {

	/**
	 * Constructor with a detail message.
	 * 
	 * @param message the detail message
	 */
	public NameAlreadyAssignedException(final String message) {
		super(message);
	}
}
