package de.hhn.seb.gvs.sso.shared.exceptions;

/**
 * Simple exception for communicating parameter name problems.
 * 
 * @author wnck
 *
 */
@SuppressWarnings("serial")
public class ParameterNotSupportedException extends Exception {

	/** 
	 * Constructs a {@link ParameterNotSupportedException} with no detail message. 
	 */
	public ParameterNotSupportedException() {
	}

	/** 
	 * Constructs a {@link ParameterNotSupportedException} with a detail message. 
	 * @param message the detail message.
	 */
	public ParameterNotSupportedException(final String message) {
		super(message);
	}

}
