/**
 * 
 */
package de.hhn.seb.gvs.sso.shared.exceptions;

/**
 * 
 * Gets thrown if a given token object which represents the acting instance is
 * not a valid token of the system.
 * 
 * @author wnck
 * 
 */
@SuppressWarnings("serial")
public class InvalidTokenException extends Exception {

	/**
	 * Constructor without detail.
	 */
	public InvalidTokenException() {
		super();
	}

	/**
	 * Constructor with a detail message.
	 * @param message
	 */
	public InvalidTokenException(final String message) {
		super(message);
	}

	/**
	 * Conbstructor with a Throwable.
	 * @param cause the Throwable
	 */
	public InvalidTokenException(final Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor with a detail message and a Throwable.
	 * @param message the detail message
	 * @param cause the Throwable
	 */
	public InvalidTokenException(final String message, final Throwable cause) {
		super(message, cause);
	}
	
}
