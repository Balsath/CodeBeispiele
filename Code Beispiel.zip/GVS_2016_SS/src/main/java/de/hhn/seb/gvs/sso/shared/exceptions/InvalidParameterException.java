package de.hhn.seb.gvs.sso.shared.exceptions;

/**
 * The InvalidParameterException gets thrown when there is a 
 * problem with a parameter. 
 * 
 * @author wnck
 * 
 */
public class InvalidParameterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4988740709321872926L;

	/** 
	 * Constructs a {@link InvalidParameterException} with no detail message. 
	 */
	public InvalidParameterException() {
	}

	/** 
	 * Constructs a {@link InvalidParameterException} with a detail message. 
	 * 
	 * @param message the detail message
	 */
	public InvalidParameterException(String message) {
		super(message);
	}

	/** 
	 * Constructs a {@link InvalidParameterException} with a detail message
	 * and a {@link Throwable}. 
	 * 
	 * @param message the detail message
	 * @param cause the throwable with further details
	 * 
	 */
	public InvalidParameterException(String message, Throwable cause) {
		super(message, cause);
	}

}
