package de.hhn.seb.gvs.sso.examples.javafx.tab1;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class Tab1Controller implements Initializable{
	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(Tab1Controller.class
			.getName());

	@FXML
	Button helloButton;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML public void sayHello(ActionEvent event) {
		System.err.println("Hello World");
	}
}
