package de.hhn.seb.gvs.sso.shared.basics;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Set;
import java.util.logging.Logger;

/**
 * 
 * Represents the knowledge about a user an SSO service will pass to a
 * requesting service.

 * @author wnck
 *
 */
public final class User implements Serializable {
	/** serialVersionUID to be updated when class changes. */
	private static final long serialVersionUID = -2540648242742441270L;

	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(User.class.getName());

	/** holds all attributes the target service should receive. */
	private HashMap<String, String> attributes;

	/** users account name in the sso. */
	public static final String USER_NAME = "username";
	/** users first name. */
	public static final String FIRST_NAME = "firstname";	
	/** users last name. */
	public static final String LAST_NAME = "lastname";
	/** users mail address. */
	public static final String EMAIL = "email";
	/** users phone number. */
	public static final String MOBILE_PHONE = "mobile_phone";
	/** users prefered nickname for the target service. */ 
	public static final String NICK_NAME = "nickname";

	/**
	 * Default Constructor.
	 */
	public User() {
		attributes = new HashMap<>();
	}

	/**
	 * Adds an attribute to the hashmap.
	 * 
	 * @param key
	 *            unique key of the attribute. Could be one of the constants of
	 *            the User class.
	 * @param value
	 *            user specific value
	 */
	public void addAttribute(final String key, final String value) {
		attributes.put(key, value);
	}

	/**
	 * removes an attribute.
	 * 
	 * @param key key of attribute to be removed.
	 */
	public void removeAttribute(final String key) {
		attributes.remove(key);
	}
	
	/**
	 * Returns the value to a given attribute key.
	 * @param key key of attribute to be searched.
	 * @return value of the attribute, may be null.
	 */
	public String getAttribute(final String key) {
		return attributes.get(key);
	}
	
	/**
	 * Returns the set of keys of the attributes.
	 * @return Set of keys
	 */
	public Set<String> getAttributes() {
		return attributes.keySet();
	}
}
