package de.hhn.seb.gvs.sso.shared.communicate.sockets;

import java.io.Serializable;

/**
 * Base class Request. Will be used in derived request classes. This class can
 * be used as a marker to make sure, that only requests are read from an
 * ObjectInputStream.
 * 
 * @author wnck
 * 
 */
public abstract class Request extends Message implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1356009878151985559L;

}
