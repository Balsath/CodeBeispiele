package de.hhn.seb.gvs.sso.shared.exceptions;

/** 
 * Wird geworfen, wenn in der verteilten Anwendung die Verbindung gestoert ist. 
 * **/
public class ServiceNotAvailableException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5185761840472986126L;

	public ServiceNotAvailableException() {
		super();
	}

	public ServiceNotAvailableException(String message) {
		super(message);
	}

	public ServiceNotAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	public ServiceNotAvailableException(Throwable cause) {
		super(cause);
	}

}
