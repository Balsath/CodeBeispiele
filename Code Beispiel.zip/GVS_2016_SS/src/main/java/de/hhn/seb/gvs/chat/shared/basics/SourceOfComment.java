package de.hhn.seb.gvs.chat.shared.basics;

public enum SourceOfComment {
	USER, SERVICE
}
