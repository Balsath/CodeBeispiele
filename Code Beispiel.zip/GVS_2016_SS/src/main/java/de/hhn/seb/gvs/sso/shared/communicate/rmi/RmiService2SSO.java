package de.hhn.seb.gvs.sso.shared.communicate.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;

public interface RmiService2SSO extends Remote {
	static final String REGISTRY_NAME = "RmiService2SSO";
	static final String RMI_REGISTRY_HOSTNAME = "rmi.registry.hostname";
	static final String RMI_REGISTRY_PORTNUMBER = "rmi.registry.portnumber";

	/**
	 * Checks if the ticket represents a valid session.
	 * 
	 * @param token
	 *            token of the user
	 * @return true, if it is a valid token, otherwise false.
	 * @throws InvalidParameterException
	 *             if the token is a null reference or comes from another
	 *             server.
	 * @throws RemoteException
	 *             if anything related to the distribution mechanism goes wrong.
	 */
	boolean validToken(Token token) throws InvalidParameterException,
			RemoteException;

	/**
	 * For a given token it returns user information which the requesting
	 * service is allowed to see.
	 * 
	 * @param token
	 *            token of the user.
	 * @param service
	 *            Identification of the requesting service.
	 * @return A user object containing only allowed attributes.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 * @throws InvalidParameterException
	 *             if the token is not correct, not a token of this server or
	 *             a null reference.
	 * @throws RemoteException
	 *             if anything related to the distribution mechanism goes wrong.
	 */
	User token2User(Token token, String service)
			throws InvalidTokenException, InvalidParameterException, RemoteException;

}
