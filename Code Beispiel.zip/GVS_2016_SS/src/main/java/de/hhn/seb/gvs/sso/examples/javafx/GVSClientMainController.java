package de.hhn.seb.gvs.sso.examples.javafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;

public class GVSClientMainController implements Initializable {
	private static final Logger logger = Logger
			.getLogger(GVSClientMainController.class.getName());

	@FXML
	AnchorPane tab1;

	@FXML
	AnchorPane tab2;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

//		AnchorPane root1;
		try {
			Parent root1 = FXMLLoader.load(getClass().getResource(
					"tab1/Tab1.fxml"));
			tab1.getChildren().add(root1);

			Parent root2 = FXMLLoader.load(getClass().getResource(
					"tab2/Tab2.fxml"));
			tab2.getChildren().add(root2);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
