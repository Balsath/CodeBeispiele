package de.hhn.seb.gvs.chat.client;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public interface BDChatService {
	/**
	 * login for a user based on his token. The chat server will evaluate the
	 * token against the Service2SSO interface of the server addressed in the
	 * token.
	 * 
	 * @param token
	 *            token of a user which is logged in at an SSO service
	 * @throws InvalidTokenException
	 *             if the evaluation of the token against the sso service fails or the connection to the sso fails
	 * @throws InvalidParameterException
	 * 				if the token or the client object have not the correct structure and information
	 */
	void login(Token token) throws InvalidTokenException, InvalidParameterException,
			ServiceNotAvailableException;

	/**
	 * The logout removes the client from the push list of clients. The client will not get any new 
	 * messages and he cannot send any messages any more.
	 * 
	 * @param token
	 *            token of a user which is logged in at an SSO service
	 * @throws InvalidTokenException
	 *             if the evaluation of the token against the sso service fails
	 * @throws InvalidParameterException
	 * 				if the token has not the correct structure and information
	 */
	void logout(Token token) throws InvalidTokenException, InvalidParameterException,
			ServiceNotAvailableException;

	/**
	 * The client sends a comment to the chat service for publication.
	 * 
	 * @param token
	 *            token of a user which is logged in at an SSO service
	 * @param comment
	 *            a string with minimal one visible character and a maximum length of
	 *            Comment.MAX_CONTENT_LENGTH
	 * @throws InvalidTokenException
	 *             if the evaluation of the token against the sso service fails
	 * @throws InvalidParameterException
	 *             if the comment is not appropriate, e.g. too short, too long
	 */
	void sendComment(Token token, String comment)
			throws InvalidTokenException, InvalidParameterException, ServiceNotAvailableException;


	/**
	 * Getter for chat service identification. The returning String must not be
	 * unique. Examples: "Harry's Discussion Club", "Chat-to-Go", ...
	 * 
	 * @return name of the chat provider
	 * @throws ServiceNotAvailableException
	 *             if the communication is disturbed
	 */
	String getChatProvider() throws ServiceNotAvailableException;

	/**
	 * Returns the list of chatters actually logged in into the chat service.
	 * 
	 * @return list of names of the chatters.
	 * @throws ServiceNotAvailableException
	 *             if the communication is disturbed
	 */
	String[] getListOfChatters() throws ServiceNotAvailableException;

	/**
	 * adds a listener for callbacks of the chat service. If the chat server
	 * delivers a comment the listener gets called with the comment object. The
	 * implementation must be able to manage more than one listener.
	 * 
	 * @param listener
	 *            object implementing the ChatListener interface.
	 */
	void addChatListener(ChatListener listener);

	/**
	 * Removes the listener from the list of listeners.
	 * 
	 * @param listener
	 *            listener to be removed.
	 */
	void removeChatListener(ChatListener listener);

	/**
	 * Allows the user interface to pass configuration parameters to the
	 * implementing class. In case of the socket implementation this may be
	 * hostname or IP address and the port number of the SSO server. In case of
	 * Java RMI this would be hostname or IP address and the port number of the
	 * rmiregistry.
	 * 
	 * @param key
	 *            key of the parameter
	 * @param value
	 *            value of the parameter
	 * @throws ParameterNotSupportedException
	 *             when the given key is not known by the implementation.
	 * @throws InvalidParameterException
	 *             if key or value are null references or the key is no readable
	 *             string.
	 */
	void setParameter(String key, String value)
			throws ParameterNotSupportedException, InvalidParameterException;

	/**
	 * Getter for supported parameters.
	 * 
	 * @param key
	 * @return value of the parameter if the parameter is set, otherwise null.
	 * @throws ParameterNotSupportedException
	 *             if the parameter is not supported by the Implementation of
	 *             this interface.
	 */
	String getParameter(String key) throws ParameterNotSupportedException;
}
