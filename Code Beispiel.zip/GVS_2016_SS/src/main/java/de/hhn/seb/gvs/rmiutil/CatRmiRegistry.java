package de.hhn.seb.gvs.rmiutil;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Makes a "cat"-command onto a remote rmiregistry.
 * 
 * @author wnck
 *
 */
public class CatRmiRegistry {

	public CatRmiRegistry() {
	}

	public static void main(String[] args) throws Exception {
		
		String hostname = null;
		
		if (args.length == 1) {
			hostname = args[0];
		} else {
			BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please insert hostname");
			hostname = keyboard.readLine();
		}

		Registry registry = LocateRegistry.getRegistry(hostname);
		
		String[] keys = registry.list();
		
		for (String string : keys) {
			Remote remoteReference = registry.lookup(string);
			System.out.println(string + " : " + remoteReference);
		}
	}

}
