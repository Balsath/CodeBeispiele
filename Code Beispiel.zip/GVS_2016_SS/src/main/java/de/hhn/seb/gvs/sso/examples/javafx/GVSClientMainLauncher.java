package de.hhn.seb.gvs.sso.examples.javafx;

import java.io.IOException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GVSClientMainLauncher extends Application {
	private static Logger logger = Logger.getLogger(GVSClientMainLauncher.class.getName());

	@Override
	public void start(Stage stage) throws IOException {
		stage.setTitle("JavaFX User2SSO Client");
		
		stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                cleanupBeforeExit();
                Platform.exit();
            }
        });
		Parent root = FXMLLoader.load(getClass().getResource(
				"GVSClientMain.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

	}

	
	public void cleanupBeforeExit() {
		logger.info("Closing down the stuff ...");
		// TODO: Cleanup code
	}
	
	public static void main(String[] args) throws Exception {
		// TODO: Configure the logger ...
		
		// TODO: Configure JMX
		
		// Closes the application when the last stage has been closed.
		Platform.setImplicitExit(true);

		
		Platform.runLater(new Runnable() {
			public void run() {				
				// TODO: some setup code if needed
			}
		});
		
		launch(args);
		

	}
}
