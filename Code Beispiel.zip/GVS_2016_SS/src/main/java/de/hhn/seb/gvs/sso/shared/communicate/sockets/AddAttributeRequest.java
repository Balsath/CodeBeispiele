package de.hhn.seb.gvs.sso.shared.communicate.sockets;

import de.hhn.seb.gvs.sso.shared.basics.Token;


public class AddAttributeRequest extends Request {

	private Token token;
	private String key;
	private String value;
	/**
	 * @param token
	 * @param key
	 * @param value
	 */
	public AddAttributeRequest(Token token, String key, String value) {
		super();
		this.token = token;
		this.key = key;
		this.value = value;
	}
	
	
	public Token getToken() {
		return token;
	}


	public String getKey() {
		return key;
	}
	public String getValue() {
		return value;
	}
	
	
}
