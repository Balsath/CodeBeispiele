package de.hhn.seb.gvs.sso.shared.communicate.sockets;


public class RegisterRequest extends Request {
	
	private String username;
	private String password;
	private String emailAddress;
	
	/**
	 * @param username
	 * @param password
	 * @param emailAddress
	 */
	public RegisterRequest(String username, String password, String emailAddress) {
		super();
		this.username = username;
		this.password = password;
		this.emailAddress = emailAddress;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getEmailAddress() {
		return emailAddress;
	}
	
	
	
}
