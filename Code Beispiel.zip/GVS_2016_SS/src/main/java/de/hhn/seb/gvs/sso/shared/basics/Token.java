package de.hhn.seb.gvs.sso.shared.basics;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.logging.Logger;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;

/**
 * A Token represents a temporal passport in the SSO scenario.
 * 
 * @author wnck
 * 
 */
public final class Token implements Serializable {
	/** serialVersionUID to be updated when class changes. */
	private static final long serialVersionUID = 5677347287411736093L;

	/** Key to store the name of the sso provider in the token hash map. */
	public static final String SSO_PROVIDER = "sso.provider";

	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(Token.class.getName());

	/**
	 * HashMap for further information, e.g. hostname:port to contact the SSO
	 * service. Debugging info may also be in this HashMap.
	 */
	private HashMap<String, String> attributes;

	/** unique key for each token within an SSO server. */
	private String primaryKey;
	
	/** value to be incorporated into every key. */
	private static int tokenCounter;

	/** simple date formatter to generate readable primary key. */
	private static SimpleDateFormat formatter = new SimpleDateFormat(
			"dd-MM-yy_hh-mm-ss");

	/**
	 * Default constructor. The constructor creates a primary key which is not
	 * yet protected against fake.
	 * 
	 */
	public Token() {
		Date created = new Date();
		primaryKey = "Token" + "_" + tokenCounter++ + "_"
				+ formatter.format(created);
		attributes = new HashMap<>();
		logger.finer("New Token created: " + this);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		Token other = (Token) obj;

		// If the primary keys match,
		if (primaryKey == null) {
			if (other.primaryKey != null) {
				return false;
			}
		} else if (!primaryKey.equals(other.primaryKey)) {
			return false;
		}

		return true;
	}

	/**
	 * Getter for the primary key of the token object.
	 * 
	 * @return primary key of the token.
	 */
	public String getPrimaryKey() {
		return primaryKey;
	}

	@Override
	public int hashCode() {
		return primaryKey.hashCode();
	}

	/**
	 * Adds an attribute to the HashMap.
	 * 
	 * @param key
	 *            Name of the attribute
	 * @param value
	 *            Value of the attribute
	 */
	public void addAttribute(final String key, final String value) {
		if (attributes.containsKey(key)) {
			logger.warning("Token: Substituing Token Attribute " + key + " / "
					+ attributes.get(key) + " with value " + value);
		}
		attributes.put(key, value);
	}

	/**
	 * Removes an attribute from the HashMap.
	 * 
	 * @param key
	 *            Name of the attribute
	 */
	public void removeAttribute(final String key) {
		if (!attributes.containsKey(key)) {
			logger.warning("Token: Try to remove non-existing attribute " + key);
		} else {
			attributes.remove(key);
		}
		
	}

	@Override
	public String toString() {
		return "Token [attributes=" + attributes + ", primaryKey=" + primaryKey
				+ "]";
	}

	/**
	 * returns an attribute for a given key.
	 * 
	 * @param key
	 *            Name of the attribute
	 * @return value of the attribute, otherwise null
	 */
	public String getAttribute(final String key) {
		return attributes.get(key);
	}

	public static void validate(Token token) throws InvalidParameterException {
		if (token == null) {
			throw new InvalidParameterException("Token is null reference");
		}

		// SSO_PROVIDER must be set by SSO server ...
		if (token.getAttribute(Token.SSO_PROVIDER) == null) {
			throw new InvalidParameterException("No valid SSO_PROVIDER name in token " + token);
		}

		if (token.getPrimaryKey() == null) {
			throw new InvalidParameterException("Primary Key in Token is  null reference");
		}

	}
}
