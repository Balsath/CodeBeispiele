package de.hhn.seb.gvs.sso.client;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public interface BDService2SSO {

	/**
	 * Checks if the token represents a valid token.
	 * 
	 * @param token
	 *            token of the user
	 * @return true, if it is a valid token belonging to a user which is logged
	 *         on, otherwise false.
	 * @throws InvalidParameterException
	 *             if the token is a null reference or comes from another
	 *             server.
	 * @throws ServiceNotAvailableException
	 *             when something within the distribution mechanism fails
	 */
	boolean validToken(Token token) throws InvalidParameterException, ServiceNotAvailableException;

	/**
	 * For a given token it returns user information which the requesting
	 * service is allowed to see.
	 * 
	 * @param token
	 *            token of the user.
	 * @param service
	 *            Identification of the requesting service.
	 * @return A user object containing only allowed attributes.
	 * @throws InvalidTokenException
	 *             if the token does not belong to a user which is logged in.
	 * @throws InvalidParameterException
	 *             if the token is not correct, not a token of this server or
	 *             a null reference.
	 * @throws ServiceNotAvailableException
	 *             when something within the distribution mechanism fails
	 * @throws InvalidTokenException 
	 */
	User token2User(Token token, String service)
			throws InvalidParameterException, ServiceNotAvailableException, InvalidTokenException;


}
