package de.hhn.seb.gvs.sso.shared.communicate.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

/**
 * RMI version of the interface User2SSO. Every method can additionally throw the RemoteException.
 * 
 * @see de.hhn.seb.gvs.sso.service.User2SSO
 * 
 * @author wnck
 *
 */
public interface RmiUser2SSO extends Remote {
	static final String REGISTRY_NAME = "RmiUser2SSO";

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#logout(Token)
	 */
	void logout(Token token) throws InvalidTokenException,
			RemoteException, InvalidParameterException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#login(String, String)
	 */
	Token login(String username, String password)
			throws InvalidParameterException, RemoteException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#register(String, String, String)
	 */
	void register(String username, String password, String emailAddress)
			throws NameAlreadyAssignedException, InvalidParameterException,
			RemoteException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#addAttribute(Token, String, String)
	 */
	void addAttribute(final Token token, final String key,
			final String value) throws InvalidParameterException,
			InvalidTokenException, RemoteException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#removeAttribute(Token, String)
	 */
	void removeAttribute(final Token token, final String key)
			throws InvalidParameterException, InvalidTokenException,
			RemoteException;

	/**
	 * @see de.hhn.seb.gvs.sso.service.User2SSO#getAllAttributes(Token)
	 */
	User getAllAttributes(final Token token)
			throws InvalidTokenException, RemoteException, InvalidParameterException;
}
