package de.hhn.seb.gvs.chat.shared.basics;

import java.util.Date;

public interface Comment {
	static final int MAX_CONTENT_LENGTH = 200;

	/**
	 * The source of a comment marks if the comment is a user comment or a
	 * comment of the chat service.
	 * 
	 * @return Source of the comment
	 */
	SourceOfComment getSource();

	/**
	 * The content ist a nonempty string of maximal 200 characters.
	 * 
	 * @return The content
	 */
	String getContent();

	/**
	 * The author name is a concatenation of the user name and the sso provider
	 * name. The author name is a nonempty string with a maximum length of 40
	 * characters.
	 * 
	 * @return authors name of the comment.
	 */
	String getAuthorName();

	/**
	 * Every comment has an id. The ids are set by the chat server. They are unique
	 * and always increasing. This allows to sort the comments. 
	 * 
	 * @return
	 */
	int getCommentId();

	/**
	 * The timestamp marks, when the comment was received by the server. The timestamp is set by the chat server.
	 * 
	 * @return Date object marking the moment the comment was received by the server.
	 */
	Date getTimestamp();
}
