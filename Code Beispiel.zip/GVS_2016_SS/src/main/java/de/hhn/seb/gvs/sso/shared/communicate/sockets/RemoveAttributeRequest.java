package de.hhn.seb.gvs.sso.shared.communicate.sockets;

import de.hhn.seb.gvs.sso.shared.basics.Token;


public class RemoveAttributeRequest extends Request {

	private Token token;
	private String key;
	/**
	 * @param token
	 * @param key
	 */
	public RemoveAttributeRequest(Token token, String key) {
		super();
		this.token = token;
		this.key = key;
	}
	public Token getToken() {
		return token;
	}
	public String getKey() {
		return key;
	}

	
}
