/**
 * 
 */
/**
 * @author wnck
 *
 */
package de.hhn.seb.gvs.sso.shared.communicate.rmi;