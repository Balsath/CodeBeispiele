package de.hhn.seb.gvs.sso.service;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;

/**
 * This interface allows the configuration of the SSO implementation to provide
 * other services a specified set of attributes about a user. For simplicity we
 * do not authenticate the administrator.
 *
 * @author wnck
 *
 */
public interface Admin2SSO {
	/**
	 * removes a service completely.
	 *
	 * @param serviceid
	 *            identification of the service.
	 * @throws InvalidParameterException
	 *             if the identification is not known.
	 */
	void removeService(String serviceid) throws InvalidParameterException;

	/**
	 * sets the allowed attribute keys for a service. For example, the chat
	 * service is only allowed to see the nickname of the user but no other
	 * attribute.
	 *
	 * @param serviceid
	 *            identification of the service.
	 * @param attributes
	 *            String array with the keys of the allowed attributes.
	 * @throws InvalidParameterException
	 *             if the parameters are not valid.
	 */
	void setService(String serviceid, String[] attributes)
			throws InvalidParameterException;
}
