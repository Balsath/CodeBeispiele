package kuroseross.tcpmulti;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Logger;

import kuroseross.tcp.TCPServer;

/**
 * Startklasse und gleichzeitig main Thread, der die Verbindungsw�nsche
 * akzeptiert und dann einen neuen Thread abspaltet, der die Kommunikation mit
 * dem Client abwickelt.
 * 
 * @author wnck
 * 
 */
public class TCPServerWelcome {
  /** Logger, named using the complete class name. */
  private static final Logger logger = Logger.getLogger(TCPServerWelcome.class.getName());

  public static void main(String[] argv) throws Exception {
    @SuppressWarnings("resource")
    ServerSocket welcomeSocket = new ServerSocket(TCPServer.PORT);
    System.err.println("Server bereit ...");

    while (true) {

      logger.info("Ready to accept connections ...");

      Socket connectionSocket = welcomeSocket.accept();
      ServeOneClient thread = new ServeOneClient(connectionSocket);
      System.err.println("neue Verbindung auf Thread..." + thread);
    }
  }
}
