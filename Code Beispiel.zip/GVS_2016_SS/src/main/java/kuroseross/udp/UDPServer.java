package kuroseross.udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.logging.Logger;

class UDPServer {
	public static final int UDP_PORT = 19876;

	public static void main(String args[]) throws Exception {
		Logger logger = Logger.getAnonymousLogger();

		boolean running = true;
		
		logger.info("Prepare port on port number " + UDP_PORT);
		DatagramSocket serverSocket = new DatagramSocket(UDP_PORT);

		

		while (running) {
			byte[] receiveData = new byte[1024];
			byte[] sendData = new byte[1024];

			DatagramPacket receivePacket = new DatagramPacket(receiveData,
					receiveData.length);

			logger.info("Wait for datagram ...");
			serverSocket.receive(receivePacket);

			String sentence = new String(receivePacket.getData());
			logger.info("Got datagram with sentence " + sentence);

			InetAddress IPAddress = receivePacket.getAddress();

			int port = receivePacket.getPort();

			String capitalizedSentence = sentence.toUpperCase();

			sendData = capitalizedSentence.getBytes();

			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, port);
			logger.info("Answering to " + IPAddress + ": " + port);

			serverSocket.send(sendPacket);
		}
		
		serverSocket.close();
	}
}
