package kuroseross.udp;

import java.io.*;
import java.net.*;
import java.util.logging.Logger;

class UDPClient {
	public static void main(String args[]) throws Exception {
		Logger logger = Logger.getAnonymousLogger();

		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(
				System.in));

		DatagramSocket clientSocket = new DatagramSocket();

		InetAddress IPAddress = InetAddress.getByName("127.0.0.1");

		byte[] sendData = new byte[1024];
		byte[] receiveData = new byte[1024];

		String sentence = inFromUser.readLine();
		logger.info("Got Line: " + sentence);
		
		sendData = sentence.getBytes();
		
		logger.info("Sending to " + IPAddress + ":" + UDPServer.UDP_PORT);
		DatagramPacket sendPacket = new DatagramPacket(sendData,
				sendData.length, IPAddress, UDPServer.UDP_PORT);

		clientSocket.send(sendPacket);

		DatagramPacket receivePacket = new DatagramPacket(receiveData,
				receiveData.length);

		logger.info("Datagram send...waiting for answer ...");
		clientSocket.receive(receivePacket);

		String modifiedSentence = new String(receivePacket.getData());

		System.out.println("FROM SERVER:" + modifiedSentence);
		clientSocket.close();
	}
}
