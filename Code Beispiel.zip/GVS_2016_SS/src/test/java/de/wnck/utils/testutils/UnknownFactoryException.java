package de.wnck.utils.testutils;

public class UnknownFactoryException extends RuntimeException {

    public UnknownFactoryException() {
        // TODO Auto-generated constructor stub
    }

    public UnknownFactoryException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public UnknownFactoryException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public UnknownFactoryException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

}
