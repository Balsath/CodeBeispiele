package de.wnck.utils.testutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Logger;

public class FactoryFactory {
    public static final String PROPERTY_FILE = "factoryfactory.properties";

    private HashMap<String, Factory> factories;
    private Properties properties;
    private Logger logger;
    private boolean loaded;

    public FactoryFactory() {
        this.factories = new HashMap<String, Factory>();
        this.logger = Logger.getLogger(FactoryFactory.class.getName());
        this.loaded = false;
    }

    public Factory getFactory(String factoryName)
            throws UnknownFactoryException {
        if (!loaded) {
            sucheViaProperty();
        }

        Factory factory = factories.get(factoryName);

        if (factory == null) {
            throw new UnknownFactoryException("Name of requested factory is "
                    + factoryName);
        }
        return factory;
    }

    /**
     * Sucht eine Property-Datei und ruft im Erfolgsfall die Instantiierung der
     * Fabriken auf.
     * 
     */
    private void sucheViaProperty() {
        properties = new Properties();

        try {
            // Die Properties-Datei muss im aktuellen Verzeichnis liegen
            FileInputStream is = new FileInputStream(PROPERTY_FILE);
            if (is == null) {
                File file = new File(".");
                String path = file.getAbsolutePath();
                throw new IOException("Datei " + PROPERTY_FILE
                        + "  im Verzeichnis " + path
                        + " ist nicht zu bekommen.");
            }

            // Laden der Property-Datei in ein Properties-Objekt
            properties.load(is);

            // Erzeugen der Fabriken
            loadFactories();

            // Markieren, dass die Fabriken geladen sind
            loaded = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadFactories() {
        Enumeration enumeration = properties.propertyNames();

        // Iteriere �ber alle Eintr�ge ...
        while (enumeration.hasMoreElements()) {
            String key = (String) enumeration.nextElement();
            String className = properties.getProperty(key);
            loadFactory(key, className);
        }

    }

    private void loadFactory(String key, String className) {
        logger.fine("Versuche, die Klasse " + className
                + " als Implementierung f�r die Klasse " + key
                + " zu instantiieren");
        try {
            Factory factory = (Factory) Class.forName(className).newInstance();
            factories.put(key, factory);
            logger.fine("Factory instantiiert: " + className);
        } catch (InstantiationException e) {
            logger.warning("Cannot instantiate class " + className);
        } catch (IllegalAccessException e) {
            logger.warning("Cannot access class " + className);
        } catch (ClassNotFoundException e) {
            logger.warning("Cannot find class " + className);
        }

    }
}
