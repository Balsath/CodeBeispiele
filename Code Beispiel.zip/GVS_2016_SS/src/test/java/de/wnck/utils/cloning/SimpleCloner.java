package de.wnck.utils.cloning;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.logging.*;

/**
 * The SimpleCloner clones an object by serializing it into an
 * ByteArrayOutputStream (via ObjectOutputStream) and reading it back in.
 * 
 * @author wnck
 *
 */
public final class SimpleCloner {

	/**
	 * Private empty Constructor for helper class.
	 */
	private SimpleCloner() {
		super();
	}

	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(SimpleCloner.class.getName());
	/**
	 * Initial object size shall reduce size incrementation steps of the
	 * ByeArrayOutputStream.
	 */
	private static final int INITIAL_OBJECT_SIZE = 1000;

	/**
	 * clones a given object. This object must be Serializable.
	 * 
	 * @param o
	 *            Object to be cloned
	 * @return cloned version of the given object
	 * @throws IOException
	 *             thrown by problems with the ObjectStreams
	 * @throws ClassNotFoundException
	 *             this should never happen in this context because we do
	 *             serialization and deserialization direct one after the other.
	 */
	public static Object cloneIt(Object o) throws IOException, ClassNotFoundException {
		byte[] byteArray;
		Object clone;
		ByteArrayOutputStream bout = new ByteArrayOutputStream(INITIAL_OBJECT_SIZE);
		ObjectOutputStream oout = new ObjectOutputStream(bout);
		oout.writeObject(o);

		byteArray = bout.toByteArray();
		ByteArrayInputStream bin = new ByteArrayInputStream(byteArray);
		ObjectInputStream oin = new ObjectInputStream(bin);
		clone = oin.readObject();
		return clone;

	}

	/**
	 * @param args
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Date original = new Date();
		System.out.println("original = " + original);
		Date clone = (Date) SimpleCloner.cloneIt(original);
		System.out.println("clone    = " + clone);
	}
}
