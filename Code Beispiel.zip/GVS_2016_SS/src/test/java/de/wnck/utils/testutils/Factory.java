package de.wnck.utils.testutils;

/**
 * Markiert eine Schnittstelle als Fabrikschnittstelle
 * @author wnck
 *
 */
public interface Factory {

}
