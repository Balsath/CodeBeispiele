package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.Test;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOAttributesTest extends SSOTestFrame {
	private static final String DUMMY_VALUE = "dummyValue";
	private static final String DUMMY_KEY = "dummy2";
	/** Standard class logger. **/
	private static Logger logger = Logger
			.getLogger(User2SSOAttributesTest.class.getName());

	@Test
	public final void addAndRemoveTest() {
		try {
			registerOneUser();
			loginOneUser();
			addAttributesForOneUser();
		} catch (NameAlreadyAssignedException | InvalidParameterException
				| InvalidTokenException e) {
			fail("This all should work, pal.");
		}

		try {
			user2sso.addAttribute(session, DUMMY_KEY, DUMMY_VALUE);
			assertEquals(DUMMY_VALUE, user2sso.getAllAttributes(session)
					.getAttribute(DUMMY_KEY));
			user2sso.removeAttribute(session, DUMMY_KEY);
			assertNull("After removal the attribute should not be available",
					user2sso.getAllAttributes(session).getAttribute(DUMMY_KEY));
		} catch (InvalidParameterException | InvalidTokenException e) {
			fail("This all should work, pal.");
		}
		
		try {
			user2sso.removeAttribute(session, DUMMY_KEY);
		} catch (InvalidParameterException e) {
			fail("Trying to remove non existing attributes is not forbidden.");
		} catch (InvalidTokenException e) {
			fail("This all should work, pal.");
		}

	}

	/**
	 * Try to set attributes with an old session.
	 */
	@Test
	public final void badSessionWithAttributesTest() {
		
		Token badSession = null;
		Token goodSession = null;
		try {
			registerOneUser();
			badSession = user2sso.login(HUGO, SECRET);
			user2sso.logout(badSession);
			goodSession = user2sso.login(HUGO, SECRET);
		} catch (NameAlreadyAssignedException | InvalidParameterException
				| InvalidTokenException e) {
			fail("This all should work, pal.");
		}
		
		try {
			user2sso.addAttribute(badSession, DUMMY_KEY, DUMMY_VALUE);
			fail("This is an invalid token (already logged out)");
		} catch (InvalidParameterException e) {
			fail("Ups, wrong Exception. InvalidTokenException expected.");
		} catch (InvalidTokenException e) {
			// success
		}
		
		/**
		 * Now try to do correct stuff ...
		 */
		try {
			goodSession = user2sso.login(HUGO, SECRET);
			user2sso.addAttribute(goodSession, DUMMY_KEY, DUMMY_VALUE);
		} catch (InvalidParameterException | InvalidTokenException e) {
			fail("This all should work, pal.");
		}
		
	}
	
	@Test
	public void badParametersWithAttributesTest() {
		try {
			registerOneUser();
			loginOneUser();
		} catch (NameAlreadyAssignedException | InvalidParameterException e) {
			fail("This all should work, pal.");
		}
		
		/**
		 * no session
		 */
		try {
			user2sso.addAttribute(null, DUMMY_KEY, DUMMY_VALUE);
			fail("You should not add an attribute without a valid token.");
		} catch (InvalidParameterException e) {
			// success
		} catch (InvalidTokenException e) {
			fail("Ups, wrong Exception. InvalidParameterException expected.");
		}

		/**
		 * no key
		 */
		try {
			user2sso.addAttribute(session, null, DUMMY_VALUE);
			fail("You should not add an attribute without a valid key.");
		} catch (InvalidParameterException e) {
			// success
		} catch (InvalidTokenException e) {
			fail("Ups, wrong Exception. InvalidParameterException expected.");
		}

		/**
		 * no value
		 */
		try {
			user2sso.addAttribute(session, DUMMY_KEY, null);
			fail("You should not add an attribute without a valid value.");
		} catch (InvalidParameterException e) {
			// success
		} catch (InvalidTokenException e) {
			fail("Ups, wrong Exception. InvalidParameterException expected.");
		}

	}
}
