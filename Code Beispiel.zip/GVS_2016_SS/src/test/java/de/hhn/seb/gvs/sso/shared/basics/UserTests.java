package de.hhn.seb.gvs.sso.shared.basics;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class UserTests {

	private static final String KEY1 = "key1";
	private static final String KEY2 = "key2";
	private static final String VALUE1 = "value1";

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAddAndGetAttribute() {
		User user = new User();
		user.addAttribute(KEY1, VALUE1);
		String value = user.getAttribute(KEY1);
		assertTrue(VALUE1.equals(value));
	}

	@Test
	public void testRemoveAttribute() {
		User user = new User();
		user.addAttribute(KEY1, VALUE1);
		user.removeAttribute(KEY1);
		String result = user.getAttribute(KEY1);
		assertNull(result);
	}

	@Test
	public void testGetAttributes() {
		User user = new User();
		user.addAttribute(KEY1, VALUE1);
		user.addAttribute(KEY2, VALUE1);
		Set<String> result = user.getAttributes();
		// check if there are all entries
		assertEquals(2, result.size());
		// check if the given keys are available
		assertTrue(result.contains(KEY1));
		assertTrue(result.contains(KEY2));
	}

}
