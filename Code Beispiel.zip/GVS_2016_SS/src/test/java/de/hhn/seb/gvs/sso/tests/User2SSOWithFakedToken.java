package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOWithFakedToken extends SSOTestFrame {
	Token correctToken;


	
	public void prepareLocalTest() {
		try {
			registerOneUser();
			correctToken = loginOneUser();
			user2sso.logout(correctToken);
		} catch (NameAlreadyAssignedException | InvalidParameterException | InvalidTokenException e) {
			e.printStackTrace();
			fail("Hey, this should work.");
		}
	}
	
	@Test
	public void testLogoutWithFakeToken() {
		prepareLocalTest();
		Token fakeToken = new Token();
		copyAllAttributes(correctToken, fakeToken);
		try {
			user2sso.logout(fakeToken);
		} catch (InvalidTokenException e) {
			e.printStackTrace();
			fail("Hey, this is a faked token. I stole your provider name.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	private void copyAllAttributes(Token correctToken2, Token fakeToken) {
		String provider = correctToken2.getAttribute(Token.SSO_PROVIDER);
		fakeToken.addAttribute(Token.SSO_PROVIDER, provider);
		
	}
	

}
