package de.hhn.seb.gvs.sso.tests;

import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

@RunWith(Parameterized.class)
public class User2SSORegisterWithInvalidEmailAddresses extends SSOTestFrame {
	
	@Parameterized.Parameters
	public static List data() {
		return Arrays.asList(new Object[]{
				"hugo",
//				"hugo@de",
				"@de.com",
				"hugo@",
				".hugo.egon@was.de",
				"hugo@egon@dot.de"
		});
	}

	private String address;
	
	@Rule
    public ExpectedException thrown= ExpectedException.none();
	
	public User2SSORegisterWithInvalidEmailAddresses(String address) {
		this.address = address;
	}
	
	@Test
	
	public void checkRegisterWithÀddress() throws NameAlreadyAssignedException, InvalidParameterException {
		thrown.expect(InvalidParameterException.class);
		user2sso.register("hugo", "long secret", address);
	}

}
