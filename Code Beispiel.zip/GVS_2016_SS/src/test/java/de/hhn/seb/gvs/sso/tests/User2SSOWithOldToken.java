package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOWithOldToken extends SSOTestFrame {
	Token token;


	
	public void prepareLocalTest() {
		try {
			registerOneUser();
			token = loginOneUser();
			user2sso.logout(token);
		} catch (NameAlreadyAssignedException | InvalidParameterException | InvalidTokenException e) {
			e.printStackTrace();
			fail("Hey, this should work.");
		}
	}
	
	@Test
	public void testLogoutWithOldToken() {
		prepareLocalTest();
		try {
			user2sso.logout(token);
		} catch (InvalidTokenException e) {
			// success
		} catch (InvalidParameterException e) {
			e.printStackTrace();
			fail("Hey, this is YOUR token. Can't you recognize it?");
		}
	}
	
	@Test
	public void testGetAllAttributesWithOldToken() {
		prepareLocalTest();
		try {
			User user = user2sso.getAllAttributes(token);
		} catch (InvalidTokenException e) {
			// success
		} catch (InvalidParameterException e) {
			e.printStackTrace();
			fail("Hey, this is YOUR token. Can't you recognize it?");
		}		
	}
	
	@Test
	public void testAddAttributeWithOldToken() {
		prepareLocalTest();
		try {
			user2sso.addAttribute(token, "key", "value");
		} catch (InvalidTokenException e) {
			// success
		} catch (InvalidParameterException e) {
			e.printStackTrace();
			fail("Hey, this is YOUR token. Can't you recognize it?");
		}		
	}
	
	@Test
	public void testRemoveAttributeWithOldToken() {
		prepareLocalTest();
		try {
			user2sso.removeAttribute(token, "key");
		} catch (InvalidTokenException e) {
			// success
		} catch (InvalidParameterException e) {
			e.printStackTrace();
			fail("Hey, this is YOUR token. Can't you recognize it?");
		}		
	}
}
