package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOLogoutTest extends SSOTestFrame {
	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(User2SSOLogoutTest.class
			.getName());

	/**
	 * Login and logout. Should work ....
	 */
	@Test
	public final void correctLogoutTest() {
		Token session1 = null;
		try {
			registerOneUser();
			session1 = loginOneUser();
		} catch (NameAlreadyAssignedException | InvalidParameterException e) {
			fail("This should work.");
		}
		
		try {
			user2sso.logout(session1);
		} catch (InvalidTokenException e) {
			fail("This should work.");
		} catch (InvalidParameterException e) {
			fail("This should work.");
		}
	}
	
	
	/**
	 * Logout with null reference. 
	 */
	@Test
	public final void logoutWithNullReferenceTest() {
		try {
			user2sso.logout(null);
			fail("This should NOT work.");
		} catch (InvalidTokenException e) {
			fail("This must be an InvalidParameterException.");
		} catch (InvalidParameterException e) {
			// success
		}
	}
	/**
	 * Logout twice. Should fail on the second try.
	 */
	@Test
	public final void wrongLogoutTest() {
		Token session1 = null;
		try {
			registerOneUser();
			session1 = loginOneUser();
		} catch (NameAlreadyAssignedException | InvalidParameterException e) {
			fail("This should work.");
		}
		
		try {
			user2sso.logout(session1);
		} catch (InvalidTokenException e) {
			fail("This should work.");
		} catch (InvalidParameterException e) {
			fail("This should work.");
		}

		try {
			user2sso.logout(session1);
			fail("This should NOT work.");
		} catch (InvalidTokenException e) {
			// success
		} catch (InvalidParameterException e) {
			fail("This is the wrong exception.");
		}

		
	}
}
