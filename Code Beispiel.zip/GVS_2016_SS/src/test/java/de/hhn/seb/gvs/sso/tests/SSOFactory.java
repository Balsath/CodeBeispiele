package de.hhn.seb.gvs.sso.tests;

import de.hhn.seb.gvs.sso.service.Admin2SSO;
import de.hhn.seb.gvs.sso.service.Service2SSO;
import de.hhn.seb.gvs.sso.service.User2SSO;
import de.wnck.utils.testutils.Factory;

/**
 * SSOFactory implements the design pattern "Abstract Factory" (See E. Gamma:
 * Design Patterns).
 * 
 * Through the factory the team specific implementations of the project
 * interfaces are available.
 * 
 * @author Winckler
 * 
 * @see FactoryFactory, Factory
 * 
 */
public interface SSOFactory extends Factory {
	public static final String FACTORY_NAME = SSOFactory.class.getName();

	/**
	 * returns a User2SSO object which is or interacts with the SSO Server.
	 * 
	 * @return Object representing the User2SSO interface of the SSO Server.
	 */
	User2SSO getUser2SSO();

	/**
	 * returns a Service2SSO object which is or interacts with the SSO Server.
	 * 
	 * @return Object representing the Service2SSO interface of the SSO Server.
	 */
	Service2SSO getService2SSO();

	/**
	 * returns a Admin2SSO object which is or interacts with the SSO Server.
	 * 
	 * @return Object representing the Admin2SSO interface of the SSO Server.
	 */
	Admin2SSO getAdmin2SSO();

	/**
	 * 
	 * Resets the SSO server. After reset the new SSO object has no registered
	 * users.
	 */
	void resetServer();

}
