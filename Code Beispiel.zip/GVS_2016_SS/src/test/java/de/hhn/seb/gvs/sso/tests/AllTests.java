package de.hhn.seb.gvs.sso.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Test suite containing all released junit test for the SSO server.
 * 
 * @author wnck
 * 
 */
@RunWith(Suite.class)
@SuiteClasses({ User2SSORegisterTest.class, User2SSOLoginTest.class,
		User2SSOLogoutTest.class, AdminAndService2SSOTest.class,
		User2SSOAttributesTest.class, User2SSOWithForeignToken.class, User2SSOWithOldToken.class,
		User2SSOWithFakedToken.class, User2SSORegisterWithValidEmailAddresses.class, User2SSORegisterWithInvalidEmailAddresses.class})
public class AllTests {
}
