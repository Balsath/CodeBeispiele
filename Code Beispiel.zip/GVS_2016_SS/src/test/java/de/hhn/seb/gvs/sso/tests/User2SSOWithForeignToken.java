package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOWithForeignToken extends SSOTestFrame {

	@Test
	public void testWithForeignToken() {
		Token foreignToken = new Token();
		foreignToken.addAttribute(Token.SSO_PROVIDER, "Quite-a-different-sso-provider-4fs639d5fg4r52");

		try {
			User attributes = user2sso.getAllAttributes(foreignToken);
			fail("This is a foreign token. There should be no information associated with it.");
		} catch (InvalidParameterException e) {
			// success
		} catch (InvalidTokenException e) {
			fail("This is a foreign token, not created by this user2sso implementation. How can you check that a token is your token?!?");
		}

		try {
			user2sso.logout(foreignToken);
			fail("This is a foreign token. There should be no information associated with it.");
		} catch (InvalidParameterException e) {
			// success
		} catch (InvalidTokenException e) {
			fail("This is a foreign token, not created by this user2sso implementation. How can you check that a token is your token?!?");
		}

	
	}


}
