package de.hhn.seb.gvs.sso.shared.basics;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.wnck.utils.cloning.SimpleCloner;

public class TokenTests {

	private static final String VALUE1 = "value1";
	private static final String KEY1 = "key1";

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testEqualsObject() throws ClassNotFoundException, IOException {
		Token token1 = new Token();
		Token token2 = (Token) SimpleCloner.cloneIt(token1);
		assertTrue(token1.equals(token2));
		// Only the key identifies a token, even when the attributes have changed.
		token2.addAttribute(KEY1, VALUE1);
		assertTrue(token1.equals(token2));
	}

	@Test
	public void testAddAttribute() {
		Token token1 = new Token();
		token1.addAttribute(KEY1, VALUE1);
		String value = token1.getAttribute(KEY1);
		assertEquals("String coming in should be the same as String coming out", VALUE1, value);
	}

	@Test(expected = InvalidParameterException.class)
	public void testValidateWithBadToken() throws InvalidParameterException {
		Token token1 = new Token();
		Token.validate(token1);
		fail("This is an invalid token because there is no attribute related to the sso provider.");
	}

	public void testValidateWithBGoodToken() throws InvalidParameterException {
		Token token1 = new Token();
		token1.addAttribute(Token.SSO_PROVIDER, "Hugo-SSO");
		Token.validate(token1);
	}

}
