package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class User2SSOLoginTest extends SSOTestFrame {
	
	@Before
	public final void setup() {
		try {
			registerOneUser();
		} catch (NameAlreadyAssignedException | InvalidParameterException e) {
			fail("This should work.");
		}
	}

	
	@Test
	public final void loginWithBadParametersTest() {

		try {
			user2sso.login(null, null);
			fail("This should NOT work.");
		} catch (InvalidParameterException e) {
			// success
		}
	}


	@Test
	public void loginWithNullUserName() {
		try {
			user2sso.login(null, SECRET);
			fail("This should NOT work.");
		} catch (InvalidParameterException e) {
			// success
		}
	}


	@Test
	public void loginWithNullPassword() {
		try {
			user2sso.login(HUGO, null);
			fail("This should NOT work.");
		} catch (InvalidParameterException e) {
			// success
		}
	}
	
	@Test
	public final void loginSeveralTimesTest() {

		try {
			Token session1 = user2sso.login(HUGO, SECRET);
			Token session2 = user2sso.login(HUGO, SECRET);
			assertEquals(session1, session2);
			assertSame(session1, session2);
		} catch (InvalidParameterException e) {
			fail("This should work.");
		}

		
	}
}
