package de.hhn.seb.gvs.sso.tests;

import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

@RunWith(Parameterized.class)
public class User2SSORegisterWithValidEmailAddresses extends SSOTestFrame {
	
	@Parameterized.Parameters
	public static List data() {
		return Arrays.asList(new Object[]{
				"hugo@test.de",
				"hugo.egon@test.de",
				"hugo.\"the Man\".egon@de.com",
				"hugo!egon@dot.de"
		});
	}

	private String address;
	
	
	public User2SSORegisterWithValidEmailAddresses(String address) {
		this.address = address;
	}
	
	@Test
	
	public void checkRegisterWithÀddress() throws NameAlreadyAssignedException, InvalidParameterException {
		user2sso.register("hugo", "long secret", address);
	}

}
