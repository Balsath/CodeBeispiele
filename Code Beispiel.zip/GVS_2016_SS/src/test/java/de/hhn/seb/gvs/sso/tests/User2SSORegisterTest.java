package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Categories.ExcludeCategory;

import de.hhn.seb.gvs.sso.service.User2SSO;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.wnck.utils.testutils.FactoryFactory;


public class User2SSORegisterTest extends SSOTestFrame {

	private static final String TOO_SHORT_PASSWORD = "1234567";
	private static final String LONGSECRET = "longsecret";

	@Test
	public final void registerTwoTimesWithTheSameUserName() {
		try {
			user2sso.register("hugo", LONGSECRET, "hugo@hugo.de");
		} catch (NameAlreadyAssignedException | InvalidParameterException e) {
			fail("This should work.");
		}
		try {
			// second try, with the same name
			user2sso.register("hugo", LONGSECRET, "hugo@hugo.de");
			fail("registering two times with the same name should fail.");
		} catch (InvalidParameterException e) {
			fail("This is the wrong exception.");
		} catch (NameAlreadyAssignedException e) {
			// success
		}
	}

	@Test
	public void registerWithUserNameContainingABlank() {
		try {
			user2sso.register("hugo egon", LONGSECRET, "hugo@hugo.de");
		} catch (NameAlreadyAssignedException e) {
			fail("This should work.");
		} catch (InvalidParameterException e) {
			fail("This should work.");
		}
	}
	
	@Test 
	public final void registerWithTooShortPassword ()  {
		try {
			user2sso.register("hugo", TOO_SHORT_PASSWORD, "hugo@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Test
	public void registerWithInvalidEmailAdresses() {
		try {
			user2sso.register("hugo", LONGSECRET, "hugo");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}

		try {
			user2sso.register("hugo", LONGSECRET, "@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Test
	public void registerWithNullEmailAddress() {
		try {
			user2sso.register("hugo", LONGSECRET, null);
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Test
	public void registerWithNullUserName() {
		try {
			user2sso.register(null, LONGSECRET, "hugo@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Test
	public void registerWithNullPassword() {
		try {
			user2sso.register("hugo", null, "hugo@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}
	
	@Test
	public void registerWithEmptyPassword() {
		try {
			user2sso.register("hugo", "", "hugo@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Test
	public void registerWithEmptyUserName() {
		try {
			user2sso.register("", LONGSECRET, "hugo@hugo.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}
	}

	@Ignore
	public final void moreDifficultMailTest() {
		try {
			user2sso.register("hugo", LONGSECRET, "hugo@hugo and empty space.de");
			fail("This should NOT work.");
		} catch (NameAlreadyAssignedException e) {
			fail("Wrong exception.");
		} catch (InvalidParameterException e) {
			// success
		}

		
	}
}
