package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Categories.ExcludeCategory;

import de.hhn.seb.gvs.sso.service.Admin2SSO;
import de.hhn.seb.gvs.sso.service.Service2SSO;
import de.hhn.seb.gvs.sso.service.User2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.wnck.utils.testutils.FactoryFactory;


public abstract class SSOTestFrame {
	private static final String DEFAULT_PHONE_NUMBER = "0170 555 12 34";

	private static final String EGON = "egon";

	/** Standard class logger. **/
	private static Logger logger = Logger.getLogger(SSOTestFrame.class
			.getName());

	protected static FactoryFactory factoryfactory;
	protected static SSOFactory ssoFactory;

	public static final String HUGO = "Hugo";
	public static final String SECRET = "longsecret";
	public static final String HUGO_MAIL = "hugo@hugo.de";
	
	protected User2SSO user2sso;
	protected Service2SSO service2sso;
	protected Admin2SSO admin2sso;

	protected Token session;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		factoryfactory = new FactoryFactory();
		ssoFactory = (SSOFactory) factoryfactory.getFactory(SSOFactory.FACTORY_NAME);
	}

	@Before
	public void setUpLocalTest() throws Exception {
		user2sso = ssoFactory.getUser2SSO();
		service2sso = ssoFactory.getService2SSO();
		admin2sso = ssoFactory.getAdmin2SSO();
	}

	@After
	public void teardown() {
		ssoFactory.resetServer();
	}

	protected void registerOneUser() throws NameAlreadyAssignedException,
			InvalidParameterException {
				user2sso.register(HUGO, SECRET, HUGO_MAIL);
			}

	protected Token loginOneUser() throws InvalidParameterException {
		session = user2sso.login(HUGO, SECRET);
		return session;
	}
	
	protected void addAttributesForOneUser() throws InvalidParameterException, InvalidTokenException {
		user2sso.addAttribute(session, User.NICK_NAME, EGON);
		user2sso.addAttribute(session, User.MOBILE_PHONE, DEFAULT_PHONE_NUMBER);
	}
}
