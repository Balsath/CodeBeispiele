package de.hhn.seb.gvs.sso.tests;

import static org.junit.Assert.*;

import java.util.logging.Logger;

import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class AdminAndService2SSOTest extends SSOTestFrame {
  private static final String DUMMY_SERVICE1 = "dummyService1";
  /** Standard class logger. **/
  private static Logger logger = Logger.getLogger(AdminAndService2SSOTest.class.getName());

  @Test
  public final void test() {
    String[] allowedAttributes = { User.NICK_NAME, User.USER_NAME };
    try {
      registerOneUser();
      loginOneUser();
      // puts in additional attributes NICK_NAME and MOBILE_PHONE
      addAttributesForOneUser();
    } catch (NameAlreadyAssignedException | InvalidParameterException | InvalidTokenException e) {
      fail("This should work.");

    }

    // configure some attributes
    try {
      admin2sso.setService(DUMMY_SERVICE1, allowedAttributes);
    } catch (InvalidParameterException e) {
      fail("This should work.");
    }

    try {
      // the user himself has access to ALL attributes
      User myself = user2sso.getAllAttributes(session);
      // the service has only access to the attributes configured in the 
      // setService call above
      User serviceUser = service2sso.token2User(session, DUMMY_SERVICE1);

      // checks that all attributes are available over the User2SSO interface
      assertNotNull(myself.getAttribute(User.NICK_NAME));
      assertNotNull(myself.getAttribute(User.MOBILE_PHONE));
      assertNotNull(myself.getAttribute(User.USER_NAME));
      assertNotNull(myself.getAttribute(User.EMAIL));

      // checks that only the allowed attributes are given via the Service2SSO interface
      assertNotNull(serviceUser.getAttribute(User.NICK_NAME));
      assertNotNull(serviceUser.getAttribute(User.USER_NAME));
      assertNull(serviceUser.getAttribute(User.MOBILE_PHONE));
      assertNull(serviceUser.getAttribute(User.EMAIL));

    } catch (InvalidTokenException e) {
      fail("This should work.");
    } catch (InvalidParameterException e) {
      fail("This should work.");
    }

  }
}
