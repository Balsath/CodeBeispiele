$(function() {
	
	function changeUserLandlord() {


        console.log("Function");
        $.ajax({
            type: "Put",
            url: "api/me",
            // The key needs to match your method's input parameter (case-sensitive).
            data: JSON.stringify({
               
				  username: $("#busername").val(),
                email: $("#bemail").val(),
                firstname: $("#bfirstname").val(),
                lastname: $("#blastname").val(),
				landlord: document.getElementById('LableLinktoLandLord').innerHTML
            }),
            contentType: "application/json; charset=utf-8",
            success: function () {
               showConfirmMessage("Vermieter hinzugefügt", "Ihnen  wurde erfolgreich ein Vermieter hinzugefügt");

                location.reload();


            },
           	error: function () {
      showErrorMessage("Nope", "Das hat leider nicht geklappt");

                
                getbUser();
            }
        });
    }


    function updateActivity() {
		
        $.ajax({
            type: "GET",
            url: "api/user",

            contentType: "application/json; charset=utf-8",
            success: function (user) {
					
					
					
                var activityTable = d3.select("#myTable").select("tbody");
				
                var selection = activityTable.selectAll("tr").data(user, function(d) {
                    return d.username;
                });

                var row = selection.enter()
                    .append("tr")
                    .style("opacity", 0);

              
				row.append("td").text(function (msg) {
					console.log(msg.username);
					return msg.username;
                    
                });
				
				  row.on("click", function (msg) {
                 var username = msg.username;
					 document.getElementById('LableLinktoLandLord').innerHTML = username;
					   $("#newVermieter-modal").modal("hide");
					   showConfirmMessage(" Vermieter gesetzt", "Sie haben erfolgreich ihren Vermieter angegeben");
					   var link = document.getElementById("LableLinktoLandLord");
					link.setAttribute("href", "messenger#new/"+ msg.username);
					   
						
                });


         
				 
				

                selection.exit()
                    .transition()
                    .style("opacity", 0)
                    .remove();

                row.transition()
                    .style("opacity", 1);
            },

            	error: function () {
      
     showErrorMessage("Nope", "Das hat leider nicht geklappt");
  
                
                getbUser();
            }
        });
		
    }
	(function(document) {
	'use strict';

	var LightTableFilter = (function(Arr) {

		var _input;

		function _onInputEvent(e) {
			_input = e.target;
			var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
	
	  
				
	

	   
	

  

    $("#btnchoosevermieter").click(function() {
       $("#newVermieter-modal").modal("show");
	    updateActivity();
    });
 
    
	    
  
   
});