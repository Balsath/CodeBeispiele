CREATE TABLE Buch(
	titel VARCHAR NOT NULL,
	jahr INTEGER NOT NULL,
	isbn VARCHAR UNIQUE,
	PRIMARY KEY(isbn)
);

CREATE TABLE Mitglied(
	nr INTEGER UNIQUE,
	adresse VARCHAR NOT NULL,
	PRIMARY KEY(nr),
);

CREATE TABLE bestelltVor(
	bestellDatum Date NOT NULL,
	isbn VARCHAR NOT NULL,
	nr INTEGER NOT NULL,
	vorbestellungsID INTEGER UNIQUE,
	CONSTRAINT isbn_fkey FOREIGN KEY isbn REFERENCES Buch (isbn) ON UPDATE CASCADE,
	CONSTRAINT nr_fkey FOREIGN KEY nr REFERENCES Mitglied (nr) ON UPDATE CASCADE,
	PRIMARY KEY (vorbestellungsID)
);

1.4.a

SELECT *
FROM Buch B
WHERE 	B.jahr < 2005 AND
		B.isbn NOT IN (
			SELECT DISTINCT AV.isbn
			FROM ausgeliehenVon AV
			--WHERE B.isbn = AV.isbn Braucht man das?
		)

1.4.b

SELECT 	(SELECT B.titel FROM Buch B WHERE B.isbn = AV.isbn) AS titel
		(SELECT B.isbn FROM Buch B WHERE B.isbn = AV.isbn) AS isbn
FROM ausgeliehenVon AV
GROUP BY isbn
HAVING 	COUNT(isbn) > (
			SELECT AVG(D.durchschnitt)
			FROM (
				SELECT COUNT(AV.isbn) AS durchschnitt
				FROM ausgeliegenVon AV
				GROUP BY AV.isbn
			) AS D
		)

		
