$(function () {
    var iD;
    var userI;

    function getUser() {

        $.ajax({
            type: "GET",
            url: "api/me",

            contentType: "application/json; charset=utf-8",
            success: function (data) {


                userI = data.username


            },

              	error: function () {
        showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
        });
    }

    function createActivity() {
        var user;
        $.ajax({
            type: "GET",
            url: "api/me",

            contentType: "application/json; charset=utf-8",
            success: function (data) {


                user = data.username


            },

               	error: function () {
        showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
        });

        $.ajax({


            type: "Post",
            url: "api/activity",
            // The key needs to match your method's input parameter (case-sensitive).
            data: JSON.stringify({
                title: $("#titlefield").val(),
                description: $("#subjectfield").val(),
                category: $("#catecoryfield").val(),
                date: $("#datfield").val(),
                creator: user
            }),
            contentType: "application/json; charset=utf-8",
            success: function () {
               
                document.getElementById("subjectfield").value = "";
                document.getElementById("catecoryfield").value = "";
                document.getElementById("datfield").value = "";
                document.getElementById("titlefield").value = "";
                $("#newActivity-modal").modal("hide");
				
                updateActivity();

            },
               	error: function () {
    showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
        });
    }

    function updateActivity() {
        $('#loading_indicator').show();
        getUser();

        $.ajax({
            type: "GET",
            url: "api/activity",

            contentType: "application/json; charset=utf-8",
            success: function (activity) {

                var subscriberJ = [];


                var teilnehmerliste = $('#teilnehmerliste');
                var activityTable = d3.select("#activity").select("tbody");
				

                var selection = activityTable.selectAll("tr").data(activity, function (d) {
                    return d.id;
                });

                var row = selection.enter()
                    .append("tr")
                    .style("opacity", 0);

                row.append("td").text(function (msg) {
                    subscriberJ = msg.subcriber;
                    return msg.title;

                });

                row.append("td").text(function (msg) {
                    return msg.category;
                });
                row.append("td").text(function (msg) {
                    var creator = msg.creator;
                    return creator.username;

                });

                row.append("td").text(function (msg) {
                    return (msg.date).toLocaleString();
                });

                row.append("td").html(function (msg) {
                    var subscriberI = [];
                    var antwort = '<i class="fa fa-check" aria-hidden="true" style="color: #65B329"></i>';
                    subscriberI = msg.subcriber;
                    if (subscriberI.length != 0) {
                        
                    }
                    for (var i = 0; i < subscriberI.length; i++) {

                        if (subscriberI[i].username == userI) {
                            return antwort;
                        }
                    }
                });


                row.on("click", function (msg) {
                    var creator = msg.creator;
                    var subscriber = [];
                    subscriber = msg.subcriber;
                    var savechange = $("#btnUupdateActivity");
                    var deleterino = $("#btndeleteActivity");
                    var inputfeld = $("#titleInput");
                    var descriptionfeld = $("#descriptionInput");
                    var categoryfeld = $("#categoryInput");
                    var datefeld = $("#dateInput");


                    var option = new Option();
                    console.log(subscriber.length);
                    if (subscriber.length != 0) {
                        for (var i = 0; i < subscriber.length; i++) {


                            option.text = subscriber[i].username;
                        }
                        document.getElementById('teilnehmerliste').style.display = 'block';
                        document.getElementById('teilnehmerlabel').style.display = 'block';

                        teilnehmerliste.append($(option));
                    }
                    else {


                    }


                    if (creator.username == userI) {
                        savechange.prop("disabled", false);
                        deleterino.prop("disabled", false);
                        categoryfeld.prop("disabled", false);
                        datefeld.prop("disabled", false);
                        inputfeld.prop("disabled", false);
                        descriptionfeld.prop("disabled", false);

                    }
                    else {
                        if (subscriber.length != 0) {
                            for (var i = 0; i < subscriber.length; i++) {

                                if (subscriber[i].username == userI) {
                                    document.getElementById('btnretierActivity').style.display = 'block';
                                    document.getElementById('btnassignActivity').style.display = 'none';
                                }
                                else {
                                    document.getElementById('btnassignActivity').style.display = 'block';
                                    document.getElementById('btnretierActivity').style.display = 'none';
                                }
                            }
                        }
                        else {
                            document.getElementById('btnassignActivity').style.display = 'block';
                            document.getElementById('btnretierActivity').style.display = 'none';
                        }
                    }


                    iD = msg;
                    document.getElementById("creatorInput").value = creator.username;
                    document.getElementById("categoryInput").value = msg.category;
                    document.getElementById("dateInput").value = msg.date;
                    document.getElementById("titleInput").value = msg.title;
                    document.getElementById("descriptionInput").value = msg.description;
                    $("#showActivity-modal").modal("show");


                });


                selection.exit()
                    .transition()
                    .style("opacity", 0)
                    .remove();

                row.transition()
                    .style("opacity", 1);
            },

            complete: function () {
                $('#loading_indicator').hide();
            },

            error: function () {
                  showErrorMessage("Nope", "Das hat leider nicht geklappt");
            }
        });
    }


    function assignActivity(d) {
        $.ajax({
            type: "POST",
            url: "api/activity/" + d.id + "/register",
            // The key needs to match your method's input parameter (case-sensitive).


            contentType: "application/json; charset=utf-8",
            success: function () {
               showConfirmMessage(" Für Aktivität angemeldet", "Sie wurde erflogreich Der Aktivtät als Nutzer hinzugefügt");

                $("#showActivity-modal").modal("hide");
                location.href = "/aktivitaet";
            },
          	error: function () {
        showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
        });
    }

    function retiereActivity(d) {
        var r = confirm("Möchten sie ihren wirklich von der Aktivität abmelden");
        if (r) {
            $.ajax({
                type: "POST",
                url: "api/activity/" + d.id + "/deregister",
                // The key needs to match your method's input parameter (case-sensitive).


                contentType: "application/json; charset=utf-8",
                success: function () {
                    showConfirmMessage(" Von Aktivität abgemeldet", "Sie wurde erflogreich von der Aktivtät abgemeldet");

                    $("#showActivity-modal").modal("hide");
                    location.href = "/aktivitaet";
                },
                    	error: function () {
       showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
            });
        }
    }

    function deleteActivity(d) {
        var r = confirm("Möchten sie die Aktivität wirklich löschen");
        if (r) {
            $.ajax({
                type: "DELETE",
                url: "api/activity/" + d.id,
                // The key needs to match your method's input parameter (case-sensitive).


                contentType: "application/json; charset=utf-8",
                success: function () {
                    showConfirmMessage(" Aktivität gelöscht", "Sie haben die Aktivität erfolgreich gelöscht");

                    $("#showActivity-modal").modal("hide");
                    location.href = "/aktivitaet";
                },
                    	error: function () {
      showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
            });
        }
    }

    function workOnActivity(d) {
        var user;
        $.ajax({
            type: "GET",
            url: "api/me",

            contentType: "application/json; charset=utf-8",
            success: function (data) {


                user = data.username


            },
    	error: function () {
        showErrorMessage("Nope", "Das hat leider nicht geklappt");
    
            }
        });

        $.ajax({
            type: "PUT",
            url: "api/activity/" + d.id,
            // The key needs to match your method's input parameter (case-sensitive).

            data: JSON.stringify({
                title: $("#titleInput").val(),
                description: $("#descriptionInput").val(),
                category: $("#categoryInput").val(),
                date: $("#dateInput").val(),
                creator: user
            }),


            contentType: "application/json; charset=utf-8",
            success: function () {
               

                $("#showActivity-modal").modal("hide");
				 showConfirmMessage(" Aktivität Erfolgreich bearbeitet", "Sie haben die Aktivität erfolgreich bearbeitet");
                location.href = "/aktivitaet";
            },
               	error: function () {
					  showErrorMessage("Nope", "Das hat leider nicht geklappt");
     
    
            }
        });
    }
	(function(document) {
	'use strict';

	var LightTableFilter = (function(Arr) {

		var _input;

		function _onInputEvent(e) {
			_input = e.target;
			var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
	

    $("#btnNewActivity").click(function () {
        $("#newActivity-modal").modal("show");
    });

    $("#btnCreateActivity").click(function () {
        createActivity();
    });
    $("#btnassignActivity").click(function () {
        assignActivity(iD);
    });
    $("#btnretierActivity").click(function () {
        retiereActivity(iD);
    });
    $("#btndeleteActivity").click(function () {
        deleteActivity(iD);
    });
    $("#btnUupdateActivity").click(function () {
        workOnActivity(iD);
    });


    $("#btnUpdateActivity").click(updateActivity);
    updateActivity();

});