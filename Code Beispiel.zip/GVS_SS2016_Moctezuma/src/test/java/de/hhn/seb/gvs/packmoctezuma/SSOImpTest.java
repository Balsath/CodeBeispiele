package de.hhn.seb.gvs.packmoctezuma;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;


public class SSOImpTest {
    
    SSOImplementierung testSSO = new SSOImplementierung();

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    	testSSO.register("TestDude", "hallo123", "TimHardenacke@web.de");
        
    }

    @After
    public void tearDown() throws Exception {
    	
    }
    
    //Register Tests
    //Registrieren Erfolgreich.
//    @Test
//    	public void testRegistersucess() throws NameAlreadyAssignedException, InvalidParameterException {  
//   	 testSSO.register("TestDummy", "hallo123", "TimHardenacke@web.de");
//   	 assertEquals(true, testSSO.getRegUser().containsKey("TestDummy") );
//    }
     //Name nicht angegeben
     @Test(expected = InvalidParameterException.class)  
     public void testRegisterFailUserName() throws NameAlreadyAssignedException, InvalidParameterException {  
    	 testSSO.register("", "hallo123", "TimHardenacke@web.de");
    
        }
     // Email  nicht angegeben
     @Test(expected = InvalidParameterException.class)  
     public void testRegisterFailEmail() throws NameAlreadyAssignedException, InvalidParameterException {  
          testSSO.register("Test Dude", "hallo123", "");
        }
     //Password zu kurz
     @Test(expected = InvalidParameterException.class)  
     public void testRegisterFailPassword() throws NameAlreadyAssignedException, InvalidParameterException {  
          testSSO.register("Test Dude", "hallo", "TimHardenacke@web.de");
        }
     
  // Name schon vergeben
     @Test(expected = NameAlreadyAssignedException.class)  
     public void testRegisterNamealreadyassgined() throws NameAlreadyAssignedException, InvalidParameterException {  
          testSSO.register("TestDude", "hallo123", "TimHardenacke@web.de");
     	}
     
//     // Email schon vergeben (Nicht mit unsere Implementierung testba!!!!r)
     @Test(expected = NameAlreadyAssignedException.class)  
    public void testRegisteremailalreadyassgined() throws NameAlreadyAssignedException, InvalidParameterException {  
          testSSO.register("TestDuder", "hallo123", "TimHardenacke@web.de");
      
   		}
     
     //Email nicht gültig.
     @Test(expected = InvalidParameterException.class)  
     public void testRegisteremailinvalid() throws NameAlreadyAssignedException, InvalidParameterException {  
          testSSO.register("TestDuder", "hallo123", "TimHardenackeweb.de");
     		}
     
   // _____________________________________________________________________________________________________________________ 
     
     //LogIN
     
//  // Sucess
//     public void testLoginsucess() throws NameAlreadyAssignedException, InvalidParameterException {  
//       	 testSSO.login("TestDummy", "hallo123");
//       	 assertEquals(true, testSSO.getExistToken().containsKey("TestDummy") );
//        }
}
