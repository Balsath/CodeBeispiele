package de.hhn.seb.gvs.packmoctezuma;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import de.hhn.seb.gvs.sso.tests.AllTests;

@RunWith(Suite.class)
@SuiteClasses({AllTests.class })
//SSOImpTest.class
public class MoctezumaTestSuite {

}
