package de.hhn.seb.gvs.packmoctezuma;

import de.hhn.seb.gvs.sso.service.Admin2SSO;
import de.hhn.seb.gvs.sso.service.Service2SSO;
import de.hhn.seb.gvs.sso.service.User2SSO;
import de.hhn.seb.gvs.sso.tests.SSOFactory;

public class SSOFactoryImplementierung implements SSOFactory {
    
    private SSOImplementierung sso;
    
    private SSOImplementierung nonNullSSO() {
        if (sso == null) {
            sso = new SSOImplementierung();
        }
        return sso;
    }
    
    @Override
    public User2SSO getUser2SSO() {
        return nonNullSSO();
    }

    @Override
    public Service2SSO getService2SSO() {
        return nonNullSSO();
    }

    @Override
    public Admin2SSO getAdmin2SSO() {
        return nonNullSSO();
    }

    @Override
    public void resetServer() {
        sso = null;
        
    }

}
