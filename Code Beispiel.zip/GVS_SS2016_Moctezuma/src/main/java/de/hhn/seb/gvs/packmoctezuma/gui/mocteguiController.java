package de.hhn.seb.gvs.packmoctezuma.gui;


import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import de.hhn.seb.gvs.chat.client.ChatListener;
import de.hhn.seb.gvs.chat.shared.basics.Comment;
import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;

import de.hhn.seb.gvs.packmoctezuma.communication.BDUser2SSOViaMock;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUser2SSOViaSockets;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUserViaRMIUi;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUserViaSocketsUi;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUserini;
import de.hhn.seb.gvs.packmoctezuma.communication.rmi.BDUSer2SSOViaRMI;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;
import dee.hhn.seb.gvs.packmoctezuma.chat.mock.BDChatServiceViaMock;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.TextFlow;

public  class mocteguiController implements Initializable, ChatListener{
    
        ObservableList<String> keyList = FXCollections.observableArrayList();   
        
        ObservableList<String> valueList = FXCollections.observableArrayList();
        
        ObservableList<String> chatterlist =FXCollections.observableArrayList();
        
        //private BDUser2SSOViaSockets mockgui = BDUserViaSocketsUi.getsocket();
        private BDUser2SSOViaMock mockgui = BDUserini.getMock();
       // private BDUSer2SSOViaRMI mockgui = BDUserViaRMIUi.getRMI();
        private static BDChatServiceViaMock chatservice;        
        private Token unsereSitzung;
        //------------------------------Chat-Tab----------------------------------------
        

        @FXML
        private Label lonline;
        @FXML
        private Label lServerChatName;
        
        @FXML
        private TextField tfportchat;
        
        @FXML
        private TextField tfipchat;
        
        @FXML
        private Button btnDisconnectChat;
        
        @FXML
        private Button btnConnectChat;
        
        @FXML
        private Button BtnSendChat;

        @FXML
        private TextArea ChatWriteArea;
        
        @FXML
        private TextArea  ChatAreaView;
        
        @FXML
        private ListView<String> ChatViewerList;
        
        @FXML
        void DisconnectOnAction(ActionEvent event) throws InvalidTokenException, InvalidParameterException, ServiceNotAvailableException {
        	lServerChatName.setText("");
        	  chatservice.logout(unsereSitzung);
        	  chatservice.removeChatListener((ChatListener) this);
        	  chatservice = null;
        	  ChatAreaView.setText("");
        	  ChatViewerList.setItems(null);
        	  lonline.setText("OFFLINE");
        	  lonline.setTextFill(Color.web("#FF0000"));
        	  btnConnectChat.setDisable(false);
        	  btnDisconnectChat.setDisable(true);
        	  }

        @FXML
        void ConnectOnAction(ActionEvent event) throws ServiceNotAvailableException, InvalidTokenException, InvalidParameterException, NameAlreadyAssignedException {
        	 chatservice = BDChatServiceViaMock.getService(); 
        	 ChatAreaView.setEditable(false);
        	  
        	  chatservice.login(unsereSitzung);
        	
        	  chatservice.addChatListener((ChatListener) this);
        	  lServerChatName.setText(chatservice.getChatProvider());
        	  LoggerUtil.getLogger().info("Chatserver ip: " + tfipchat.getText() + " Port: " + tfportchat.getText() );
        	  
        	  ObservableList<String> items =FXCollections.observableArrayList (
        		      chatservice.getListOfChatters());
        		  ChatViewerList.setItems(items);
        		  lonline.setText("ONLINE");
            	  lonline.setTextFill(Color.web("#00FF00"));
            	  btnConnectChat.setDisable(true);
            	  btnDisconnectChat.setDisable(false);
        	  

        		

        }
        
        @FXML
        void btSendAction(ActionEvent event) {
        	   try {
        		      chatservice.sendComment(unsereSitzung, ChatWriteArea.getText());
        		      ChatWriteArea.setText("");
        		    } catch (InvalidTokenException | InvalidParameterException | ServiceNotAvailableException e) {
        		      e.printStackTrace();
        		    }
        		  }
        
        
        
        //------------------------------End Chat-Tab--------------------------------------------

        @FXML
        private Tab tablog;
    
        @FXML
        private TextArea talog;
        
        @FXML
        private TextArea tareg;

        @FXML
        private TextField tfserverreg;


        @FXML
        private TextField tfemailreg;

        @FXML
        private Button btLog;

        @FXML
        private TextField tfportlog;

        @FXML
        private TextField tfpasswortreg;

        @FXML
        private TextField tfusernamelog;

        @FXML
        private TextField tfserverlog;

        @FXML
        private TextField tfvalue;

        @FXML
        private Button btdelete;

        @FXML
        private ListView<String> listViewValue;

        @FXML
        private ListView<String> listViewKey;

        @FXML
        private Button btreg;

        @FXML
        private Button btchange;

        @FXML
        private TextField tfportreg;

        @FXML
        private Label labelnutzer;

        @FXML
        private TextField tfpasswortlog;

        @FXML
        private TextField tfusernamereg;

        @FXML
        private TextField tfkey;
        
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
        	selectedList();
        }
        @FXML
        void btLoginAction(ActionEvent event) {
           
          if(btLog.getText().contentEquals("Log In")){
            if(tfserverlog.getText().isEmpty()) {
                LoggerUtil.getLogger().severe("Keinen Server angegeben");
                talog.setText(talog.getText() + "\n" + "Sie müssen einen Server angeben um fortfahren zu können");
            }
            if(tfportlog.getText().isEmpty()){
                LoggerUtil.getLogger().severe("Keinen Port angegeben");
                talog.setText(talog.getText() + "\n" + "Sie müssen einen Port angeben um fortfahren zu können");    
                }
            try {
            	mockgui.setParameter("ip", tfserverlog.getText());
            	mockgui.setParameter("port", tfportlog.getText());
                unsereSitzung = mockgui.login(tfusernamelog.getText(), tfpasswortlog.getText());
                LoggerUtil.getLogger().info("Login erfolgreich");
                talog.setText(talog.getText() + "\n" + "Login erfolgreich");
                tablog.setText("Logout");
                btLog.setText("Log Out");
                tfusernamelog.setEditable(false);
                tfpasswortlog.setEditable(false);
                tfserverlog.setEditable(false);
                tfportlog.setEditable(false);
                fillAttributesList();
               
                
            } catch (InvalidParameterException e) {
                talog.setText(talog.getText() + "\n" + e.getMessage());
            } catch (ServiceNotAvailableException e) {
                Alert noService = new Alert(AlertType.ERROR);
                noService.setTitle("ERROR");
                noService.setHeaderText("Service nicht erreichbar");
                noService.setContentText("Bitte prüfen sie ihre Verbindungen");
                noService.showAndWait();
          
                talog.setText(talog.getText() + "\n" + "Service nicht verfügbar" );  
                } catch (InvalidTokenException e) {
                talog.setText(talog.getText() + "\n" + e.getMessage());
            } catch (ParameterNotSupportedException e) {
            	   talog.setText(talog.getText() + "\n" + e.getMessage());
				}
                return;
            }
          
          if(btLog.getText().contentEquals("Log Out")){
              try {
                mockgui.logout(unsereSitzung);
                valueList.clear();
                keyList.clear();
                listViewKey.refresh();
                listViewValue.refresh();
                unsereSitzung = null;
                talog.setText(talog.getText() + "\n" + "Sie haben sich erfolgreich ausgeloggt");
                LoggerUtil.getLogger().info("Logout erfolgreich");
                tablog.setText("Login");
                btLog.setText("Log In");
                tfusernamelog.setEditable(true);
                tfpasswortlog.setEditable(true);
                tfserverlog.setEditable(true);
                tfportlog.setEditable(true);
                
            } catch (InvalidTokenException e) {
                talog.setText(talog.getText() + "\n" + e.getMessage());
            } catch (ServiceNotAvailableException e) {
                Alert noServicelo = new Alert(AlertType.ERROR);
                noServicelo.setTitle("ERROR");
                noServicelo.setHeaderText("Service nicht erreichbar");
                noServicelo.setContentText("Bitte prüfen sie ihre Verbindungen");
                noServicelo.showAndWait();
          
                talog.setText(talog.getText() + "\n" + "Service nicht verfügbar");  
            } catch (InvalidParameterException e) {
                talog.setText(talog.getText() + "\n" + e.getMessage());
            }
              return;
          }
        }
        
        @FXML
        void btRegAction(ActionEvent event) {
        	
                if(tfserverreg.getText().isEmpty()){
                    LoggerUtil.getLogger().severe("Keinen Server angegeben");
                    tareg.setText(tareg.getText() + "\n" + "Sie müssen einen Server angeben um fortfahren zu können");
                if(tfportreg.getText().isEmpty()){
                    LoggerUtil.getLogger().severe("Keinen Port angegeben");
                    tareg.setText(tareg.getText() + "\n" + "Sie müssen einen Port angeben um fortfahren zu können");    
                    }
                }
                try {
                	mockgui.setParameter("ip", tfserverreg.getText());
                	mockgui.setParameter("port", tfportreg.getText());
                	
                    mockgui.register(tfusernamereg.getText(), tfpasswortreg.getText(), tfemailreg.getText());
                    LoggerUtil.getLogger().info("Registrierung erfolgreich");
                    tareg.setText(tareg.getText() + "\n" + "Sie haben sich erfolgreich registriert");  
                } catch (NameAlreadyAssignedException e) {
                    tareg.setText(tareg.getText() + "\n" + e.getMessage());
                } catch (InvalidParameterException e) {
                    tareg.setText(tareg.getText() + "\n" + e.getMessage());
                } catch (ServiceNotAvailableException e) {
                    Alert noServicereg = new Alert(AlertType.ERROR);
                    noServicereg.setTitle("ERROR");
                    noServicereg.setHeaderText("Service nicht erreichbar");
                    noServicereg.setContentText("Bitte prüfen sie ihre Verbindungen");
                    noServicereg.showAndWait();
              
                    tareg.setText(tareg.getText() + "\n" + "Service nicht verfügbar");  
                 
                } catch (ParameterNotSupportedException e) {
                	tareg.setText(tareg.getText() + "\n" + e.getMessage());  		}
                
                
                
        }
        

        @FXML
        void btChangeAction(ActionEvent event) {
                if(tfvalue.getText().isEmpty()){
                    Alert noValue = new Alert(AlertType.WARNING);
                    noValue.setTitle("WARNUNG");
                    noValue.setHeaderText("Keinen Wert eingetragen");
                    noValue.setContentText("Bitte tragen sie einen Wert ein");
                    noValue.showAndWait();
                    return;
                }
                if(tfkey.getText().isEmpty()){
                    Alert noValue = new Alert(AlertType.WARNING);
                    noValue.setTitle("WARNUNG");
                    noValue.setHeaderText("Keinen Schlüssel eingetragen");
                    noValue.setContentText("Bitte tragen sie einen Schlüssel ein");
                    noValue.showAndWait();
                    return;
                }
               
                    try {if(keyList.contains(listViewKey.getSelectionModel().getSelectedItem())){
                    	mockgui.removeAttribute(unsereSitzung, listViewKey.getSelectionModel().getSelectedItem());
                    }
                    		mockgui.addAttribute(unsereSitzung, tfkey.getText(), tfvalue.getText());
                    		tfkey.clear();
			                tfvalue.clear();
			                listViewKey.getSelectionModel().clearSelection();
			                listViewValue.getSelectionModel().clearSelection();
			               
			                fillAttributesList();
					} catch (InvalidParameterException e) {
						Alert noValue = new Alert(AlertType.WARNING);
	                    noValue.setTitle("WARNUNG");
	                    noValue.setHeaderText("Paramter");
	                    noValue.setContentText("Invalid paramter");
	                    noValue.showAndWait();
	                    return;
						
					} catch (InvalidTokenException e) {
						Alert noValue = new Alert(AlertType.WARNING);
	                    noValue.setTitle("WARNUNG");
	                    noValue.setHeaderText("Tokken");
	                    noValue.setContentText("Invalid Tokken");
	                    noValue.showAndWait();
	                    return;
						
					} catch (ServiceNotAvailableException e) {
						Alert noValue = new Alert(AlertType.WARNING);
	                    noValue.setTitle("WARNUNG");
	                    noValue.setHeaderText("Service not Avalibale");
	                    noValue.setContentText("Service not Avalibale");
	                    noValue.showAndWait();
	                    return;
					}
                    
                }

             
                
                
        
              
        @FXML
        void btdeleteAction(ActionEvent event)  {
            if(listViewKey.getSelectionModel().getSelectedItem() == null || tfkey == null ||tfkey.getText().isEmpty()){
                Alert noValue = new Alert(AlertType.WARNING);
                noValue.setTitle("WARNUNG");
                noValue.setHeaderText("Keine Auswahl getroffen");
                noValue.setContentText("Bitte wählen sie ein Attribut aus, das sie löschen möchten");
                noValue.showAndWait();
                return;
            }

            

            try {
				mockgui.removeAttribute(unsereSitzung, tfkey.getText());
				  tfkey.clear();
		            tfvalue.clear();
		            fillAttributesList();
			} catch (InvalidParameterException e) {
				Alert noValue = new Alert(AlertType.WARNING);
                noValue.setTitle("WARNUNG");
                noValue.setHeaderText("Paramter");
                noValue.setContentText("Invalid paramter");
                noValue.showAndWait();
                return;
			} catch (InvalidTokenException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();Alert noValue = new Alert(AlertType.WARNING);
                noValue.setTitle("WARNUNG");
                noValue.setHeaderText("Tokken");
                noValue.setContentText("Invalid Tokken");
                noValue.showAndWait();
                return;
			} catch (ServiceNotAvailableException e) {
				Alert noValue = new Alert(AlertType.WARNING);
                noValue.setTitle("WARNUNG");
                noValue.setHeaderText("Service not Avalibale");
                noValue.setContentText("Service not Avalibale");
                noValue.showAndWait();
                return;
			}
          
          
        }
        
        private void fillAttributesList() throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException {
        	valueList.clear();
            keyList.clear();
            
            
            User listUser = mockgui.getAllAttributes(unsereSitzung);
            keyList.addAll(listUser.getAttributes());
            String key = "";
            
            for(int i = 0; i < keyList.size(); i++){
                key = keyList.get(i);
                valueList.add(listUser.getAttribute(key));     
            }
            labelnutzer.setText(valueList.get(0));
            listViewValue.setItems(valueList);
            listViewKey.setItems(keyList);
            
    
        }
       
        	
        
        
        private void selectedList(){
        
        listViewValue.getSelectionModel().selectedItemProperty().addListener((observerable, oldValue, newValue)-> {
            tfvalue.setText(listViewValue.getSelectionModel().getSelectedItem());
            if(listViewValue.getSelectionModel().getSelectedIndex() >= 0)
            tfkey.setText(keyList.get(listViewValue.getSelectionModel().getSelectedIndex()));
           
        });
        listViewKey.getSelectionModel().selectedItemProperty().addListener((observerable, oldValue, newValue)-> {
            tfkey.setText(listViewKey.getSelectionModel().getSelectedItem()); 
            if(listViewKey.getSelectionModel().getSelectedIndex() >= 0)
            tfvalue.setText(valueList.get(listViewKey.getSelectionModel().getSelectedIndex()));
            
          });
        }

		@Override
		public void showComment(Comment comment) {
			
			    String text = ChatAreaView.getText() + comment.getAuthorName() +": " + comment.getContent() + "\n";
			    ChatAreaView.setText(text);
			    ChatAreaView.selectPositionCaret(ChatAreaView.getLength()); 
			    ChatAreaView.deselect(); 
			    
			    
			    ObservableList<String> chatter;
			    
				try {
					
					chatter = FXCollections.observableArrayList (
						      chatservice.getListOfChatters());
					
					
						ChatViewerList.setItems(chatter);
				} catch (ServiceNotAvailableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        		  
			    
			  }
			
		}
 
