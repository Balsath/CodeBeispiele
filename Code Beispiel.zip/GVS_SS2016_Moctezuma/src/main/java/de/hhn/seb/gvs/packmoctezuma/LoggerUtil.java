package de.hhn.seb.gvs.packmoctezuma;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Util-Class for Logger.
 * @author Tim
 */
public final class LoggerUtil {
    
    /**
     * Logger for our program. 
     */
    private static Logger logger = Logger.getLogger("LoggerUtil");
    
    /**
     * Initialize logger.
     */
    private LoggerUtil() {
        setupLogger();
    
    }
    /**
     * Setup logger with external properties.
     */
    public static void setupLogger() {
        final InputStream inputStream = LoggerUtil.class.getResourceAsStream(
                "/logging.properties");
        try {
            LogManager.getLogManager().readConfiguration(inputStream);
            Handler fileHandler = new FileHandler(System.getProperty("user.home") + "\\GVS.log");
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
            
        } catch (final IOException e) {
            Logger.getAnonymousLogger().severe(
                    "Could not load default logging.properties file");
            Logger.getAnonymousLogger().severe(e.getMessage());
        }
    }
    
    /**
     * Getter f�r logger.
     * @return logger 
     */
    public static Logger getLogger() {
        return logger;
    }

}
