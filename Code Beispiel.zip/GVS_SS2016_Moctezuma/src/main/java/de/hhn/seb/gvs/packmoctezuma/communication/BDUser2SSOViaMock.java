package de.hhn.seb.gvs.packmoctezuma.communication;

import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;
import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;
/**
 * 
 * @author Manuel Pfeiffer
 *
 */

public class BDUser2SSOViaMock implements BDUser2SSO, BDUser2SSOViaMockMBean {

	/**
	 * .
	 */
	private SSOImplementierung ssoImplementierung = SSOImplementierung.getSingelton();
	private boolean isWorking = true;
	
	 public BDUser2SSOViaMock() {
		    
		  }

	@Override
	public void logout(Token token)
			throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException {

		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
		}

		ssoImplementierung.logout(token);

	}

	@Override
	public Token login(String username, String password)
			throws InvalidParameterException, ServiceNotAvailableException {
		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
			
		}
		return ssoImplementierung.login(username, password);
	}

	@Override
	public void register(String username, String password, String emailAddress)
			throws NameAlreadyAssignedException, InvalidParameterException, ServiceNotAvailableException {
		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
		}
		ssoImplementierung.register(username, password, emailAddress);

	}

	@Override
	public void addAttribute(Token token, String key, String value)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException {
		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
		}
		ssoImplementierung.addAttribute(token, key, value);

	}

	@Override
	public void removeAttribute(Token token, String key)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException {
		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
		}
		ssoImplementierung.removeAttribute(token, key);

	}

	@Override
	public User getAllAttributes(Token token)
			throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException {
		if (!isWorking == true) {
			throw new ServiceNotAvailableException();
		}
	
		return ssoImplementierung.getAllAttributes(token);

	}

	@Override
	public String getParameter(String key) throws ParameterNotSupportedException {
		

		return null;
	}

	@Override
	public void setParameter(String key, String value)
			throws ParameterNotSupportedException, InvalidParameterException {
		

	}

	@Override
	public void setCommunicationProblem() {
		 isWorking = false;
		  LoggerUtil.getLogger().info("Setzte Kommunikation Problem");
		
	}

	@Override
	public void setWorkingMode() {
		isWorking = true;
		LoggerUtil.getLogger().info("Setze Kommunikation auf funktionierend");		
	}

}
