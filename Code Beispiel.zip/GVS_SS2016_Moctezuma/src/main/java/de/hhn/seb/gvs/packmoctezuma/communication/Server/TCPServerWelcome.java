package de.hhn.seb.gvs.packmoctezuma.communication.Server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Logger;

import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;




public class TCPServerWelcome {
	public static final int PORT = 1099;
		  /** Logger, named using the complete class name. */
		  ;

		  public static void main(String[] argv) throws Exception {
		    @SuppressWarnings("resource")
		    ServerSocket welcomeSocket = new ServerSocket(TCPServerWelcome.PORT);
		    System.err.println("Server bereit ...");

		    while (true) {

		      LoggerUtil.getLogger().info("Ready to accept connections ...");

		      Socket connectionSocket = welcomeSocket.accept();
		      ServeOneClient thread = new ServeOneClient(connectionSocket);
		      System.err.println("neue Verbindung auf Thread..." + thread);
		    }
		  }
		}


