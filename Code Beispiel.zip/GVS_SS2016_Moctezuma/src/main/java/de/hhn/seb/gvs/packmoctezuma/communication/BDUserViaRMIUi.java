package de.hhn.seb.gvs.packmoctezuma.communication;

import de.hhn.seb.gvs.packmoctezuma.communication.rmi.BDUSer2SSOViaRMI;

public class BDUserViaRMIUi {

        private static BDUSer2SSOViaRMI mock;
        
        public static BDUSer2SSOViaRMI getRMI() {
             if (mock == null) {
                  mock = new BDUSer2SSOViaRMI();
            
        }
            return mock;
        
    }
}
