package de.hhn.seb.gvs.packmoctezuma.communication.rmi;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.HashMap;


import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiService2SSO;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiUser2SSO;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public class BDUSer2SSOViaRMI implements BDUser2SSO {
    
    private HashMap<String,String> parameter = new HashMap<>();
    private RmiUser2SSO rmiImpl;
    private String ip;
    private int port;
    

    @Override
    public void logout(Token token) throws InvalidTokenException,
            ServiceNotAvailableException, InvalidParameterException {
        try {
            rmiImpl.logout(token);
        } catch (RemoteException e) {
            
           throw new ServiceNotAvailableException(e.getMessage());
        }
        
    }

    @Override
    public Token login(String username, String password)
            throws InvalidParameterException, ServiceNotAvailableException {
  
         try {
           setUser();
           Token token = rmiImpl.login(username, password);
           token.addAttribute(RmiService2SSO.RMI_REGISTRY_HOSTNAME, ip);
           token.addAttribute(RmiService2SSO.RMI_REGISTRY_PORTNUMBER, new Integer(port).toString());
           
           return token;
                   
        } catch (RemoteException e) {
            throw new ServiceNotAvailableException(e.getMessage());
        }
    }

    @Override
    public void register(String username, String password, String emailAddress)
            throws NameAlreadyAssignedException, InvalidParameterException,
            ServiceNotAvailableException {
        try {
            setUser();
            rmiImpl.register(username, password, emailAddress);
        } catch (RemoteException e) {
            throw new ServiceNotAvailableException(e.getMessage());
        }
        
    }

    @Override
    public void addAttribute(Token token, String key, String value)
            throws InvalidParameterException, InvalidTokenException,
            ServiceNotAvailableException {
        try {
            rmiImpl.addAttribute(token, key, value);
        } catch (RemoteException e) {
            throw new ServiceNotAvailableException(e.getMessage());
        }
        
    }

    @Override
    public void removeAttribute(Token token, String key)
            throws InvalidParameterException, InvalidTokenException,
            ServiceNotAvailableException {
       try {
        rmiImpl.removeAttribute(token, key);
    } catch (RemoteException e) {
        throw new ServiceNotAvailableException(e.getMessage());
    }
        
    }

    @Override
    public User getAllAttributes(Token token) throws InvalidTokenException,
            ServiceNotAvailableException, InvalidParameterException {
        try {
             return rmiImpl.getAllAttributes(token);
        } catch (RemoteException e) {
            throw new ServiceNotAvailableException(e.getMessage());
        }
    }

    @Override
    public String getParameter(String key)
            throws ParameterNotSupportedException {
        return parameter.get(key);
    }

    @Override
    public void setParameter(String key, String value)
            throws ParameterNotSupportedException, InvalidParameterException {
        parameter.put(key, value);
        
    }
    public void setUser() throws ServiceNotAvailableException {
        ip = parameter.get("ip");
        port = Integer.parseInt(parameter.get("port"));
        
        try {
            Registry reg = LocateRegistry.getRegistry(ip, port);
            rmiImpl = (RmiUser2SSO) reg.lookup(RmiUser2SSO.REGISTRY_NAME);
        } catch (RemoteException | NotBoundException e) {
           throw new ServiceNotAvailableException(e.getMessage());
        }
    }
 
}
