package de.hhn.seb.gvs.packmoctezuma.communication.Server;


import java.io.IOException;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;
import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.AddAttributeRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.GetAllAttributesRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.LoginRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.LogoutRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.RegisterRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.RemoveAttributeRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.Request;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.Response;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class ServeOneClient extends Thread {
		private Socket socket;
	  private SSOImplementierung ssoImplementierung = SSOImplementierung.getSingelton();
	 

	  public ServeOneClient(Socket socket) {
	    this.socket = socket;
	    start();
	  }
	  
	  @Override
	  public void run() {
	    ObjectInputStream inFromClient;
	    try {
	      inFromClient = new ObjectInputStream(this.socket.getInputStream());
	      ObjectOutputStream outToClient = new ObjectOutputStream(
	          this.socket.getOutputStream());

	     Object request =  inFromClient.readObject();
	     Response response = new Response((Request) request);
	     
	     if (request instanceof AddAttributeRequest) {
	       LoggerUtil.getLogger().info("AddAttribute Request");
	       AddAttributeRequest addAttributeRequest = (AddAttributeRequest) request;
	       ssoImplementierung.addAttribute(addAttributeRequest.getToken(), addAttributeRequest.getKey(), addAttributeRequest.getValue());
	     } 
	     else if (request instanceof LogoutRequest) {
	    	 LoggerUtil.getLogger().info("Logout Request");
	       LogoutRequest logoutRequest = (LogoutRequest) request;
	       ssoImplementierung.logout(logoutRequest.getToken());
	     }
	     
	     else if (request instanceof LoginRequest) {
	    	 LoggerUtil.getLogger().info("Login Request");
	       LoginRequest loginRequest = (LoginRequest) request;
	       Token token = ssoImplementierung.login(loginRequest.getUsername(), loginRequest.getPassword());
	       response.setReturnObject(token);
	     }
	     
	     else if (request instanceof RegisterRequest) {
	    	 LoggerUtil.getLogger().info("Register Request");
	       RegisterRequest registerRequest = (RegisterRequest) request;
	       ssoImplementierung.register(registerRequest.getUsername(), registerRequest.getPassword(), registerRequest.getEmailAddress());
	     } 
	     else if (request instanceof GetAllAttributesRequest) {
	    	 LoggerUtil.getLogger().info("GetAllAttributes Request");
	       GetAllAttributesRequest getAllAttributesRequest = (GetAllAttributesRequest) request;
	       
	       User user = ssoImplementierung.getAllAttributes(getAllAttributesRequest.getToken());
	       response.setReturnObject(user);
	     }
	     
	     else if (request instanceof RemoveAttributeRequest) {
	    	 LoggerUtil.getLogger().info("RemoveAttribute Request");
	       RemoveAttributeRequest removeAttributeRequest = (RemoveAttributeRequest) request;
	       ssoImplementierung.removeAttribute(removeAttributeRequest.getToken(), removeAttributeRequest.getKey());
	     }
	     
	     
	    
	      outToClient.writeObject(response);
	      socket.close();
	    } catch (IOException | InvalidParameterException | InvalidTokenException | NameAlreadyAssignedException | ClassNotFoundException e) {
	    	Alert noValue = new Alert(AlertType.WARNING);
            noValue.setTitle("WARNUNG");
            noValue.setHeaderText("Fehler");
            noValue.setContentText("Es trat folgender Fehler auf:" + e.getMessage());
            noValue.showAndWait();
            return;	    }
	    }

	  }

	


