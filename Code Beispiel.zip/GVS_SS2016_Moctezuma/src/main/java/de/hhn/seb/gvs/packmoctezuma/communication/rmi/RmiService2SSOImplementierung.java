package de.hhn.seb.gvs.packmoctezuma.communication.rmi;

import java.rmi.RemoteException;

import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiService2SSO;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;

public class RmiService2SSOImplementierung implements RmiService2SSO{
    
    private SSOImplementierung ssoImp;
    
    public RmiService2SSOImplementierung(SSOImplementierung ssoImp) {
        this.ssoImp = ssoImp;
    }
    
    
    @Override
    public boolean validToken(Token token)
            throws InvalidParameterException, RemoteException {
        
        return ssoImp.validToken(token);
    }

    @Override
    public User token2User(Token token, String service)
            throws InvalidTokenException, InvalidParameterException,
            RemoteException {
    
        return ssoImp.token2User(token, service);
    }
}
