package de.hhn.seb.gvs.packmoctezuma.communication.rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiService2SSO;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiUser2SSO;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public class StartRMI {
    
            
    public static void main(String[] args) throws ServiceNotAvailableException {
        SSOImplementierung ssoImp = SSOImplementierung.getSingelton();
        
        RmiUser2SSOImplementierung rmiUserImp = new RmiUser2SSOImplementierung(ssoImp);
        RmiService2SSOImplementierung rmiServiceImp = new RmiService2SSOImplementierung(ssoImp);
        
        try {
            LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
            Registry reg = LocateRegistry.getRegistry();
            
            //Rebind User
            RmiUser2SSO rmiUser = (RmiUser2SSO) UnicastRemoteObject.exportObject(rmiUserImp, 0);
            reg.rebind(RmiUser2SSO.REGISTRY_NAME, rmiUser);
            
            //Rebind Service
            RmiService2SSO rmiService = (RmiService2SSO) UnicastRemoteObject.exportObject(rmiServiceImp, 0);
            reg.rebind(RmiService2SSO.REGISTRY_NAME, rmiService);
            
            
        } catch (RemoteException e) {
            throw new ServiceNotAvailableException(e.getMessage());
        }
    }
}
