package de.hhn.seb.gvs.packmoctezuma.communication;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;


import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.AddAttributeRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.GetAllAttributesRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.LoginRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.LogoutRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.RegisterRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.RemoveAttributeRequest;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.Request;
import de.hhn.seb.gvs.sso.shared.communicate.sockets.Response;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public class BDUser2SSOViaSockets implements BDUser2SSO {
	private HashMap<String,String> parameter = new HashMap<>();
	private Response sendRequest(Request request) {
	    Response response = null;
	    try {
	      int port = Integer.parseInt(getParameter("port"));
	      String ip = getParameter("ip");
	      Socket socket = new Socket(ip, port);
	      ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
	      ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
	      out.writeObject(request);
	      response = (Response) in.readObject();
	      socket.close();

	    } catch (NumberFormatException | ParameterNotSupportedException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    } catch (UnknownHostException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    } catch (IOException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    } catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	    }
	    return response;
	  }

	@Override
	public void logout(Token token)
			throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException {
		LogoutRequest logoutRequest = new LogoutRequest(token);
		  Response response = sendRequest(logoutRequest);
		    if (response.getExceptionObject() instanceof InvalidTokenException) {

		      throw new InvalidTokenException();

		    } if (response.getExceptionObject() instanceof ServiceNotAvailableException) {

		      throw new ServiceNotAvailableException();

		    }
		
	}

	@Override
	public Token login(String username, String password)
			throws InvalidParameterException, ServiceNotAvailableException {
		LoginRequest loginRequest = new LoginRequest(username, password);
		Response response = sendRequest(loginRequest);
		if(response.getExceptionObject() instanceof InvalidParameterException){
			throw new InvalidParameterException();
		}
		if (response.getExceptionObject() instanceof ServiceNotAvailableException){
			throw new ServiceNotAvailableException();
		}
		return  (Token) response.getReturnObject();
	}

	@Override
	public void register(String username, String password, String emailAddress)
			throws NameAlreadyAssignedException, InvalidParameterException, ServiceNotAvailableException {
		RegisterRequest registerRequest = new RegisterRequest(username, password, emailAddress);
		Response response = sendRequest(registerRequest);
		if(response.getExceptionObject() instanceof NameAlreadyAssignedException){
			throw new NameAlreadyAssignedException("Name already Assigned");
		}
		if(response.getExceptionObject() instanceof InvalidParameterException){
			throw new InvalidParameterException();
		}
		if (response.getExceptionObject() instanceof ServiceNotAvailableException){
			throw new ServiceNotAvailableException();
		}
	}

	@Override
	public void addAttribute(Token token, String key, String value)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException {
		AddAttributeRequest addAttributeRequest = new AddAttributeRequest(token, key, value);
		Response response = sendRequest(addAttributeRequest);
		if(response.getExceptionObject() instanceof InvalidTokenException){
			throw new InvalidTokenException();
		}
		if(response.getExceptionObject() instanceof InvalidParameterException){
			throw new InvalidParameterException();
		}
		if (response.getExceptionObject() instanceof ServiceNotAvailableException){
			throw new ServiceNotAvailableException();
		}
	}

	@Override
	public void removeAttribute(Token token, String key)
			throws InvalidParameterException, InvalidTokenException, ServiceNotAvailableException {
		RemoveAttributeRequest removeAttributeRequest = new RemoveAttributeRequest(token, key);
		Response response = sendRequest(removeAttributeRequest);
		if(response.getExceptionObject() instanceof InvalidTokenException){
			throw new InvalidTokenException();
		}
		if(response.getExceptionObject() instanceof InvalidParameterException){
			throw new InvalidParameterException();
		}
		if (response.getExceptionObject() instanceof ServiceNotAvailableException){
			throw new ServiceNotAvailableException();
		}
		
	}

	@Override
	public User getAllAttributes(Token token)
			throws InvalidTokenException, ServiceNotAvailableException, InvalidParameterException {
		GetAllAttributesRequest  getAllAttributesRequest =  new GetAllAttributesRequest(token);
		Response response = sendRequest(getAllAttributesRequest);
		if(response.getExceptionObject() instanceof InvalidTokenException){
			throw new InvalidTokenException();
		}
		if(response.getExceptionObject() instanceof InvalidParameterException){
			throw new InvalidParameterException();
		}
		if (response.getExceptionObject() instanceof ServiceNotAvailableException){
			throw new ServiceNotAvailableException();
		}
		
		return (User) response.getReturnObject();
	}

	@Override
	public String getParameter(String key) throws ParameterNotSupportedException {
		 if(parameter.containsKey(key)){
			 return parameter.get(key);
		 }
		 else
			 throw new ParameterNotSupportedException();
		
	}

	@Override
	public void setParameter(String key, String value)
			throws ParameterNotSupportedException, InvalidParameterException {
		if (!(key == null) && !(value == null)) {
		      parameter.put(key, value);
		    } else {
		      throw new InvalidParameterException();
		    }
		
}
}
