package de.hhn.seb.gvs.packmoctezuma.communication;

/**
 * @author Manuel Pfeiffer
 *
 */
public interface BDUser2SSOViaMockMBean {


  void setCommunicationProblem();
  void setWorkingMode();
  
}
