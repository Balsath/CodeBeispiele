package de.hhn.seb.gvs.packmoctezuma.communication;



public class BDUserini {

	private static BDUser2SSOViaMock mock;
	
	public static BDUser2SSOViaMock getMock() {
		 if (mock == null) {
		      mock = new BDUser2SSOViaMock();
		
	}
		return mock;
	
}}