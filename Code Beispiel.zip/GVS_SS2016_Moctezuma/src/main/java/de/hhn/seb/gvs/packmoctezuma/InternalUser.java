package de.hhn.seb.gvs.packmoctezuma;

import de.hhn.seb.gvs.sso.shared.basics.User;

/**
 * 
 * @author Manuel Pfeiffer
 *
 */
public class InternalUser {

  /**
   * private user.
   */
  private User user;
  /**
   * Password String.
   */
  private String password;
  /**
   * Getter f�r User
   * @return User
   */
  public final User getUser() {
    return user;
  }
  
/**
 * Methode ob Passwort Korrekt ist.
 * @param truePassword
 * @return true or false
 */
final boolean checkPassword(final String truePassword) {
  if (password.equals(truePassword)) {
    return true;
  }
  return false;
}

  /**
   * Neuen Nutzer erzeugen.
   * @param name 
   * @param Password 
   * @param eMail 
   */
  public InternalUser(final String name, final String password, 
      final String eMail) {
    this.user = new User();
    this.user.addAttribute(User.USER_NAME, name);
    this.user.addAttribute(User.EMAIL, eMail);
    this.password = password;

  
  
}
  
}
