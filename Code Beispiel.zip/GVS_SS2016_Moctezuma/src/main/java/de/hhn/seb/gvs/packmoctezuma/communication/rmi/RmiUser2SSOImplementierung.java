package de.hhn.seb.gvs.packmoctezuma.communication.rmi;

import java.rmi.RemoteException;


import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;
import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.communicate.rmi.RmiUser2SSO;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;

public class RmiUser2SSOImplementierung implements RmiUser2SSO {
    
    private SSOImplementierung SSOImp;
    
    public RmiUser2SSOImplementierung(SSOImplementierung ssoImp) {
        this.SSOImp = ssoImp;
    }

    @Override
    public void logout(Token token) throws InvalidTokenException,
            RemoteException, InvalidParameterException {
            LoggerUtil.getLogger().info("Versuche auszuloggen");
            SSOImp.logout(token);
        
    }

    @Override
    public Token login(String username, String password)
            throws InvalidParameterException, RemoteException {
        LoggerUtil.getLogger().info("Versuche " + username + " einzuloggen");
        return SSOImp.login(username, password);
    }

    @Override
    public void register(String username, String password, String emailAddress)
            throws NameAlreadyAssignedException, InvalidParameterException,
            RemoteException {
        LoggerUtil.getLogger().info("Versuche " + username + " zu registrieren");
        SSOImp.register(username, password, emailAddress);
        
    }

    @Override
    public void addAttribute(Token token, String key, String value)
            throws InvalidParameterException, InvalidTokenException,
            RemoteException {
        LoggerUtil.getLogger().info("Versuche " + key + " hinzuzufügen");
        SSOImp.addAttribute(token, key, value);
        
    }

    @Override
    public void removeAttribute(Token token, String key)
            throws InvalidParameterException, InvalidTokenException,
            RemoteException {
        LoggerUtil.getLogger().info("Versuche " + key + " zu entfernen");
        SSOImp.removeAttribute(token, key);
        
    }

    @Override
    public User getAllAttributes(Token token) throws InvalidTokenException,
            RemoteException, InvalidParameterException {
        LoggerUtil.getLogger().info("Versuche alle Attribute zu bekommen");
        return SSOImp.getAllAttributes(token);
    }
}
