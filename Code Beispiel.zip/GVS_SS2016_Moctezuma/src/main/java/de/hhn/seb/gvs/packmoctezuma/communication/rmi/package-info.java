/**
 * 
 */
/**
 * @author Tim
 *
 */
package de.hhn.seb.gvs.packmoctezuma.communication.rmi;