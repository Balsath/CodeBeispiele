package de.hhn.seb.gvs.packmoctezuma.communication;

import de.hhn.seb.gvs.packmoctezuma.SSOImplementierung;
import de.hhn.seb.gvs.sso.client.BDService2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;

public class BDService2SSoImplementierung implements BDService2SSO {
	private SSOImplementierung ssoImplementierung = SSOImplementierung.getSingelton();
	private boolean isWorking = true;
	@Override
	public boolean validToken(Token token) throws InvalidParameterException, ServiceNotAvailableException {
		if(!isWorking == true){
			throw new ServiceNotAvailableException();
		}
		ssoImplementierung.validToken(token);
		return false;
	}

	@Override
	public User token2User(Token token, String service)
			throws InvalidParameterException, ServiceNotAvailableException, InvalidTokenException {
	if(!isWorking ==true){
		throw new ServiceNotAvailableException();
	}
	ssoImplementierung.token2User(token, service);
		return null;
	}

}
