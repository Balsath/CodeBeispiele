package de.hhn.seb.gvs.packmoctezuma.communication;
import javax.management.*;

import com.sun.jdmk.comm.HtmlAdaptorServer;

import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;

import java.lang.management.*;

/**
 * @author Manuel Pfeiffer
 *
 */
public class SimpleJMXAgent {
  private static SimpleJMXAgent simpleJMXAgent;
  private MBeanServer mbs;

  public SimpleJMXAgent(Object object) {
    mbs = ManagementFactory.getPlatformMBeanServer();
    ObjectName oName;
    ObjectName aName;
    
    HtmlAdaptorServer adapter = new HtmlAdaptorServer();
    adapter.setPort(8080);
    
    try {      
    	
      aName = new ObjectName("communicate.mock:name=Mocte");
      oName = new ObjectName("communicate.mock:type=BDUser2SSoViaMock");
      mbs.registerMBean(object, oName);
      mbs.registerMBean(adapter, aName);
    
      adapter.start();
    } catch (MalformedObjectNameException | InstanceAlreadyExistsException | MBeanRegistrationException | NotCompliantMBeanException e) {
       	LoggerUtil.getLogger().info("Problem mit SimpleJMXAgent");
       	e.printStackTrace();
    }
   
    
    
  }
  
  public static void main(String[] args) {
   SimpleJMXAgent.getSingelton(new BDUser2SSOViaMock());

  }
  /**
   * Getter Für den Singelton dieser Klasse.
   * @return Der Singelton von der Klasse SimpleJMXAgent!
   */

  public static SimpleJMXAgent getSingelton(Object object) {
    if (simpleJMXAgent == null) {
      simpleJMXAgent = new SimpleJMXAgent(object);
    }
    return simpleJMXAgent;
  }

 

}