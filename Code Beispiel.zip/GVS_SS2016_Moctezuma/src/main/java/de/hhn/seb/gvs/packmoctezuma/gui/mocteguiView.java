package de.hhn.seb.gvs.packmoctezuma.gui;



import de.hhn.seb.gvs.packmoctezuma.communication.BDUser2SSOViaMock;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUserini;
import de.hhn.seb.gvs.packmoctezuma.communication.SimpleJMXAgent;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class mocteguiView extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane root; 
        
        try {
            root = FXMLLoader.load(getClass().getResource("moctegui.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("moctegui.fxml").toExternalForm());
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    public static void main(String[] args) {
        //Falls wir den JMX Agent benutzen wollen
        //BDUSer2SSOViaRMI mock = BDUserViaRMIUi.getRMI();
    	//BDUser2SSOViaSockets mock = BDUserViaSocketsUi.getsocket();
    	BDUser2SSOViaMock mock = BDUserini.getMock();
    	SimpleJMXAgent.getSingelton(mock);
    	new Runnable() {
			public void run() {
				
			}
			
    	};
    	
    	launch(args);
        
    }
    

}
