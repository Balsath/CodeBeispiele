package de.hhn.seb.gvs.packmoctezuma;

import java.util.HashMap;
import org.apache.commons.validator.routines.EmailValidator;
import de.hhn.seb.gvs.sso.service.Admin2SSO;
import de.hhn.seb.gvs.sso.service.Service2SSO;
import de.hhn.seb.gvs.sso.service.User2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
/**
 * Implementierung der SSO_Klassen User, Service und Admin.
 * @author Tim
 *
 */
public class SSOImplementierung implements User2SSO, Service2SSO, Admin2SSO {
	/**
	 * Erzeugen einer Instance dieser Klasse;
	 */
     private static SSOImplementierung singelton;
    /**
     * HashMap für alle registrierten Benutzer.
     * K - Username
     * V - InternalUser
     */
    private HashMap<String, InternalUser> regUser = new HashMap<>();
    /**
     * HashMap für alle User die gerade online sind.
     * K - Token
     * V - InternalUser
     */
    private HashMap<Token, InternalUser> onUser = new HashMap<>();
    /**
     * HashMap für Token die gerade existieren.
     * K - Username
     * V - Token
     */
    private HashMap<String, Token> existToken = new HashMap<>();
    /**
     * HashMap für Services, String-Array für Attribute.
     * K - Servicename
     * V - Attribute 
     */
    private HashMap<String, String[]> allServices = new HashMap<>();
    
    /**
     * Methode zur Prüfung der Eingabe.
     * @param input die zu Prüfende Eingabe.
     * @return 
     * @return true wenn die Eingabe gültig ist.
     */    
    public boolean isInputValid(String input) {
        if(input == null) {
            return false;
        }
        if(input.isEmpty()) {
            return false;
        }
        return true;
    }
    
  
    
    @Override
    public void removeService(String serviceid)
            throws InvalidParameterException {
        if(!isInputValid(serviceid)) {
            LoggerUtil.getLogger().severe(serviceid + "ist kein gültiger Service");
            throw new InvalidParameterException("Kein gültiger Service");
        }
        allServices.remove(serviceid);
        LoggerUtil.getLogger().fine("Service: " + serviceid + "wurde gelöscht");
    }

    @Override
    public void setService(String serviceid, String[] attributes)
            throws InvalidParameterException {
       if(!isInputValid(serviceid)) {
           LoggerUtil.getLogger().severe("Service: " + serviceid + "ist kein gültiger Service");
           throw new InvalidParameterException("Kein gültiger Service");
       }
       if(attributes == null) {
           LoggerUtil.getLogger().severe(serviceid + ": Keine Attribute vorhanden");
           throw new InvalidParameterException("Keine gültigen Attribute");
       }
       allServices.put(serviceid, attributes);
       LoggerUtil.getLogger().fine("Service " + serviceid + "wurde erstellt");
    }

    @Override
    public boolean validToken(Token token) throws InvalidParameterException {
        if(token == null){
            LoggerUtil.getLogger().severe("Kein Token vorhanden");
            throw new InvalidParameterException("Kein Token vorhanden");
        }
        if (token.getAttribute("mz") == null){
            LoggerUtil.getLogger().severe("Kein Token vorhanden");
            throw new InvalidParameterException("Falscher Token vorhanden");
        }   
            return onUser.containsKey(token);

    }

    @Override
    public User token2User(Token token, String service)
            throws InvalidParameterException, InvalidTokenException {
        if(!validToken(token)){
            LoggerUtil.getLogger().severe("Token" + token + "ist kein g�ltiger Token");
            throw new InvalidParameterException("Ungültiger Token");
        }
/*        System.out.println(onUser.containsKey(token));
        if(!onUser.containsKey(token)) {
            LoggerUtil.getLogger().severe("Token" + token + "wird bereits benutzt");
            throw new InvalidTokenException("User ist bereits ausgeloggt");
        }*/
        if(allServices.get(service) == null){
            LoggerUtil.getLogger().severe("Service: " + service + "hat keine g�ltigen Attribute");
            throw new InvalidParameterException("Der Service ist ung�ltig");
        }
        User allowedInformations = new User();
        for(String s: allServices.get(service)){
            LoggerUtil.getLogger().fine("Attribut: " + s + "zu den erlaubten Informationen hinzugef�gt");
            allowedInformations.addAttribute(s,onUser.get(token).getUser().getAttribute(s));            
        }
        return allowedInformations;
        //Darf hier etwas leeres zur�ck gegeben werden?
        
    }

    @Override
    public void logout(Token token)
            throws InvalidTokenException, InvalidParameterException {
        if(!validToken(token)){
            LoggerUtil.getLogger().severe("Token" + token + "ist kein gültiger Token");
            throw new InvalidTokenException();
        }
        onUser.remove(token);
        LoggerUtil.getLogger().fine("User ausgeloggt");
        
        
    }

    @Override
    public Token login(String username, String password)
            throws InvalidParameterException {
        if(!isInputValid(username)){
            LoggerUtil.getLogger().severe("Benutzername nicht angegeben");
            throw new InvalidParameterException("Bitte geben sie einen Benutzernamen an");
        }
      
        if(!isInputValid(password)){
            LoggerUtil.getLogger().severe("Passwort nicht angegeben");
            throw new InvalidParameterException("Bitte geben sie ein Passwort an");
            
        }
        if(!regUser.containsKey(username)){
            LoggerUtil.getLogger().severe("Benutzername existiert nicht");
            throw new InvalidParameterException("Der angegebene Benutzer existiert nicht");
        }
        InternalUser user = regUser.get(username);
        if(!regUser.get(username).checkPassword(password)) {
            LoggerUtil.getLogger().severe("Passwort und Benutzername stimmen nicht überein");
            throw new InvalidParameterException("Passwort und Benutzername stimmen nicht überein");
        }
        Token logto = null;
        if(onUser.containsValue(user) ) 
        {//User hat bereits einen Token
            logto = existToken.get(username);
        } else {
        	//User loggt zum ersten mal ein und hat noch keinen Token
            logto = new Token();
            logto.addAttribute("mz", "valid");
            logto.addAttribute(Token.SSO_PROVIDER, "MZ_SSO-Provider");
            LoggerUtil.getLogger().fine("Neuer Token wurde erstellt");
            
        } 
        existToken.put(username, logto);
        onUser.put(logto, regUser.get(username));
        LoggerUtil.getLogger().fine("User: " + username + " ist eingeloggt");
        return logto;
    }

    @Override
    public void register(String username, String password, String emailAddress)
            throws NameAlreadyAssignedException, InvalidParameterException {
        if(regUser.containsKey(username)) {
            LoggerUtil.getLogger().severe("Benutzername bereits verwendet");
            throw new NameAlreadyAssignedException("Benutzername wird bereits verwendet");
        }
        if(regUser.containsKey(emailAddress)) {
            LoggerUtil.getLogger().severe("Email-Adresse bereits vergeben");
            throw new NameAlreadyAssignedException("Email-Adresse bereits vergeben");
        }
        if(!isInputValid(username)) {
            LoggerUtil.getLogger().severe("Benutzername nicht angegeben");
            throw new InvalidParameterException("Benutzername muss angegeben werden");
        }
        if(!isInputValid(password) || password.length() < 8) {
            LoggerUtil.getLogger().severe("Passwort nicht ausreichend");
            throw new InvalidParameterException("Das Passwort muss mindestens 8 Zeichen lang sein");
        }
        
        if(!isInputValid(emailAddress)) {
            LoggerUtil.getLogger().severe("E-Mail Adresse nicht angegeben");
            throw new InvalidParameterException("E-Mail Adresse muss angegeben werden");
           
        }
        if(!EmailValidator.getInstance().isValid(emailAddress)) {
            LoggerUtil.getLogger().severe("E-Mail Adresse nicht gültig");
            throw new InvalidParameterException("E-Mail Adresse nicht gültig, bitte prüfen");
           
        }
        InternalUser newUser = new InternalUser(username, password, emailAddress);
        LoggerUtil.getLogger().fine("Neuen User angelegt");
        regUser.put(username, newUser);
        LoggerUtil.getLogger().fine("User erfolgreich registiert");
        
        
        
    }

    @Override
    public void addAttribute(Token token, String key, String value)
            throws InvalidParameterException, InvalidTokenException {
        if(!validToken(token)){
            LoggerUtil.getLogger().severe("Token" + token + "ist kein gültiger Token");
            throw new InvalidTokenException("Ungültiger Token");
        }
        if(!isInputValid(key)){
            LoggerUtil.getLogger().severe("Falsche Eingabe");
            throw new InvalidParameterException("Keine gültige Eingabe");
        }
        if(!isInputValid(value)){
            LoggerUtil.getLogger().severe("Falsche Eingabe");
            throw new InvalidParameterException("Keine gültige Eingabe");
        }
        onUser.get(token).getUser().addAttribute(key, value);
        LoggerUtil.getLogger().fine("Attribut: " + key +  " hinzugefügt");
        
        
    }

    @Override
    public void removeAttribute(Token token, String key)
            throws InvalidParameterException, InvalidTokenException {
        if(!validToken(token)){
            LoggerUtil.getLogger().severe("Token" + token + "ist kein g�ltiger Token");
            throw new InvalidTokenException("Ungültiger Token");
        }
        if(!onUser.containsKey(token)) {
            LoggerUtil.getLogger().severe("Token" + token + "wird bereits benutzt");
            throw new InvalidTokenException("User ist bereits ausgeloggt");
        }
        onUser.get(token).getUser().removeAttribute(key);
        LoggerUtil.getLogger().fine("Attribut: " + key +  " entfernt");
    }

    @Override
    public User getAllAttributes(Token token)
            throws InvalidParameterException, InvalidTokenException {
        if(!validToken(token)){
            LoggerUtil.getLogger().severe("Token" + token + "ist kein gültiger Token");
            throw new InvalidTokenException("Ungültiger Token");
        }
        if(!onUser.containsKey(token)) {
            LoggerUtil.getLogger().severe("Token" + token + "wird bereits benutzt");
            throw new InvalidTokenException("User ist bereits ausgeloggt");
        }
        LoggerUtil.getLogger().fine("Informationen erhalten");
        return onUser.get(token).getUser();
      
    }
    /**
     * Getter Für den Singelton dieser Klasse.
     * @return Der Singelton von der Klasse SSOImplementierung
     */
    public static final SSOImplementierung getSingelton() {
      if (singelton == null) {
        singelton = new SSOImplementierung();
      }
      return singelton;
    }
    

}
