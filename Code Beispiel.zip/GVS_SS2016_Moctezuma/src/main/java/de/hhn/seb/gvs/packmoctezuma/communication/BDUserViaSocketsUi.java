package de.hhn.seb.gvs.packmoctezuma.communication;

public class BDUserViaSocketsUi {
	private static BDUser2SSOViaSockets socket;
	
	public static BDUser2SSOViaSockets getsocket() {
		 if (socket == null) {
		      socket = new BDUser2SSOViaSockets();
		
	}
		return socket;
	
}}