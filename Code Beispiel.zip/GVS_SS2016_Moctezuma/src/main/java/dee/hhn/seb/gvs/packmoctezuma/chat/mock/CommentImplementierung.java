package dee.hhn.seb.gvs.packmoctezuma.chat.mock;

import java.util.Date;

import de.hhn.seb.gvs.chat.shared.basics.Comment;
import de.hhn.seb.gvs.chat.shared.basics.SourceOfComment;

public class CommentImplementierung implements Comment{
    private SourceOfComment ourSourceOfComment;
    private String ourContent;
    private String ourAuthor;
    private int ourId;
    
    public CommentImplementierung(String author) {
        ourAuthor = author;
    }
    
    @Override
    public SourceOfComment getSource() {
        return ourSourceOfComment;
    }

    @Override
    public String getContent() {
        return ourContent;
    }

    @Override
    public String getAuthorName() {
        return ourAuthor;
    }

    @Override
    public int getCommentId() {
        return ourId;
    }

    @Override
    public Date getTimestamp() {
        Date ourDate = new Date();
        return ourDate;
    }
    
    public void setSource (SourceOfComment quelle){
        ourSourceOfComment = quelle;
    }
    
    public void setContent(String content){
        ourContent = content;
    }
    
    
    
    
}
