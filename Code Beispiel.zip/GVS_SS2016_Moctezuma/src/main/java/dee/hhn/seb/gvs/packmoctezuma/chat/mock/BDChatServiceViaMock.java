package dee.hhn.seb.gvs.packmoctezuma.chat.mock;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import de.hhn.seb.gvs.chat.client.BDChatService;
import de.hhn.seb.gvs.chat.client.ChatListener;
import de.hhn.seb.gvs.chat.shared.basics.SourceOfComment;
import de.hhn.seb.gvs.packmoctezuma.LoggerUtil;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUser2SSOViaMock;
import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;
import de.hhn.seb.gvs.sso.shared.basics.User;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ParameterNotSupportedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;
import javafx.concurrent.Task;

public class BDChatServiceViaMock implements BDChatService{
	 private boolean isInChat = false;
    private BDUser2SSO bduserMock = new BDUser2SSOViaMock(); 
    private List<User> alleChatNutzer = new ArrayList<User>(); 
    private HashMap<String,String> parameter = new HashMap<>();
    private List<ChatListener> alleChatListener = new ArrayList<ChatListener>();
    private static BDChatServiceViaMock bdChatService;   
    private static MessageGenerator messageGenerator;
    Task task;
    
    
    public static BDChatServiceViaMock getService() throws NameAlreadyAssignedException, InvalidParameterException, ServiceNotAvailableException {
        // TODO Auto-generated constructor stub
        if (bdChatService == null) {
        	bdChatService = new BDChatServiceViaMock();
        	messageGenerator = new MessageGenerator();
        }
        return bdChatService;
      }

    @Override
    public void login(Token token) throws InvalidTokenException,
            InvalidParameterException, ServiceNotAvailableException {
       
        User chatUser = bduserMock.getAllAttributes(token);
        String userName = chatUser.getAttribute(User.USER_NAME);
        sendComment(null, "Nutzer: " + userName + " hat sich eingeloggt");
        LoggerUtil.getLogger().info("Versuche Nutzer: " + userName + "einzuloggen");
        alleChatNutzer.add(chatUser);
    }

    @Override
    public void logout(Token token) throws InvalidTokenException,
            InvalidParameterException, ServiceNotAvailableException {
        
        User chatUser = bduserMock.getAllAttributes(token);
        String userName = chatUser.getAttribute(User.USER_NAME);
        sendComment(null, "Nutzer: " + userName + " hat sich ausgeloggt");
        LoggerUtil.getLogger().info("Versuche Nutzer: " + userName + "auszuloggen");
        alleChatNutzer.remove(chatUser);
    }

    @Override
    public void sendComment(Token token, String comment)
            throws InvalidTokenException, InvalidParameterException,
            ServiceNotAvailableException {

        for (int i = 0; i < alleChatListener.size(); i++) {
          CommentImplementierung comImp;
        

          if (token == null) {
        	  String k= "Server:";
        	  
            comImp = new CommentImplementierung(k);
            comImp.setContent(comment);
            comImp.setSource(SourceOfComment.SERVICE);
          }
            else {
          
            User chatUser = null;
            chatUser = bduserMock.getAllAttributes(token);
            String userName = chatUser.getAttribute(User.USER_NAME);
            comImp = new CommentImplementierung(userName);
            comImp.setContent(comment);
            comImp.setSource(SourceOfComment.USER);
            }
          alleChatListener.get(i).showComment(comImp);
        }

    }

    @Override
    public String getChatProvider() throws ServiceNotAvailableException {
        return "Azteken-Lounge";
    }

    @Override
    public String[] getListOfChatters() throws ServiceNotAvailableException {
        LoggerUtil.getLogger().info("Versuche Liste von allen Chatteilnehmern zu bekommen");
        String[] stringChatNutzer = new String[alleChatNutzer.size()];
        for(int i = 0; i < alleChatNutzer.size(); i++) {
            stringChatNutzer[i] = alleChatNutzer.get(i).getAttribute(User.USER_NAME);
        }
        return stringChatNutzer;
    }

    @Override
    public void addChatListener(ChatListener listener) {
        LoggerUtil.getLogger().info("Versuche ChatListener hinzuzufügen");
       alleChatListener.add(listener);
       startMessages();
     
    }

    @Override
    public void removeChatListener(ChatListener listener) {
        LoggerUtil.getLogger().info("Versuche ChatListener zu entfernen");
       alleChatListener.remove(listener);
    }

    @Override
    public void setParameter(String key, String value)
            throws ParameterNotSupportedException, InvalidParameterException {
        LoggerUtil.getLogger().info("Versuche Parameter hinzuzufügen");
        parameter.put(key, value);
        
    }

    @Override
    public String getParameter(String key)
            throws ParameterNotSupportedException {
        LoggerUtil.getLogger().info("Versuche Parameter zu bekommen");
        return parameter.get(key);
    }

    public void startMessages(){
    	  task = new Task<Void>() {
    	      @Override public Void call() throws InterruptedException, InvalidParameterException, ServiceNotAvailableException {
    	        messageGenerator.isIn = true; 
    	          	        
    	        isInChat = true;
    	        while(isInChat) {
    	          messageGenerator.run();
    	        }
    	        
    	        return null;
    	      }
    	  };

    	  new Thread(task).start();
        
    }
}
