package dee.hhn.seb.gvs.packmoctezuma.chat.mock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


import de.hhn.seb.gvs.chat.client.BDChatService;
import de.hhn.seb.gvs.packmoctezuma.communication.BDUserini;
import de.hhn.seb.gvs.sso.client.BDUser2SSO;
import de.hhn.seb.gvs.sso.shared.basics.Token;

import de.hhn.seb.gvs.sso.shared.exceptions.InvalidParameterException;
import de.hhn.seb.gvs.sso.shared.exceptions.InvalidTokenException;
import de.hhn.seb.gvs.sso.shared.exceptions.NameAlreadyAssignedException;
import de.hhn.seb.gvs.sso.shared.exceptions.ServiceNotAvailableException;
import javafx.application.Platform;

		public class MessageGenerator {
			private String email = "bot@web.de";
			  private String password = "ichbineinbot";
			private	 String username = "";
			private	  Token login; 
	 private HashMap<String, Token> tokenList = new HashMap<>();
	  public boolean isIn = true;
	 
	  private ArrayList<String> user = new ArrayList<>();
	 private String[] users = {"BotWalter","BotEgon","BotMurphy","Lord Moctezuma"};
	  private String[] comments = {"Hi","Wie geht es euch?","Was tut ihr gerade?","Moctezuma!","Warum spielt der VfB so grausam?","Kann mir jemand helfen?","Bitte, wie?"};
	  private BDChatService service = BDChatServiceViaMock.getService() ;
	  BDUser2SSO bdsso = BDUserini.getMock();
	  
	





public void run() throws InterruptedException, InvalidParameterException, ServiceNotAvailableException {
    
	
      Thread.sleep(1000);
      Random rng = new Random();
      int j = rng.nextInt(10);
     
    //ersten Bot einloggen.
      if(user.isEmpty()) {
        int i =  rng.nextInt(users.length - 1);
        String username = users[i]; 
        login = bdsso.login(username, password);
        Platform.runLater(new Runnable() {
          
          @Override
          public void run() {
           
            
              try {
				service.login(login);
			} catch (InvalidTokenException | InvalidParameterException | ServiceNotAvailableException e) {
				
				e.printStackTrace();
			}
            
            
          }
        });
        
        tokenList.put(username, login);
        user.add(username);
      } 
      //Text schreiben.
      if (j < 6) {
        int i  = rng.nextInt(user.size());
        username = user.get(i);
        login = tokenList.get(username);
        i = rng.nextInt(comments.length - 1);
        String comment = comments[i];
        Platform.runLater(new Runnable() {
          
          @Override
          public void run() {
           
            
              try {
				service.sendComment(login, comment);
			} catch (InvalidTokenException | InvalidParameterException | ServiceNotAvailableException e) {
				
				e.printStackTrace();
			}
            
          }
        });
        //Ausloggen
      } if (j >= 6  && j< 8) {
        
          int i =  rng.nextInt(users.length - 1);
          username = users[i]; 
          if(user.contains(username)) {
            int x  = rng.nextInt(user.size());
            username = user.get(x);
            login = tokenList.get(username);
           
            user.remove(username);
            Platform.runLater(new Runnable() {
              
              @Override
              public void run() {
                
                try {
                  
                  service.logout(login);
                  bdsso.logout(login);
                } catch (InvalidTokenException | InvalidParameterException
                    | ServiceNotAvailableException e) {
                  
                  e.printStackTrace();
                }
              }
            });
            
          } 
          
        
       
        //Einloggen
      } if (j >= 8) {
        int i =  rng.nextInt(users.length - 1);
        username = users[i]; 
        if(!user.contains(username)) {
        login = bdsso.login(username, password);
        Platform.runLater(new Runnable() {
          
          @Override
          public void run() {
            
            
              try {
				service.login(login);
			} catch (InvalidTokenException | InvalidParameterException | ServiceNotAvailableException e) {
				
				e.printStackTrace();
			}
          } 
       
        });
        
        tokenList.put(username, login);
        user.add(username);
      }
      }
    
    
    
  }

public MessageGenerator() throws NameAlreadyAssignedException, InvalidParameterException, ServiceNotAvailableException{
	for(String user:users){
	 bdsso.register(user, password, email);
	
	}
}
  
}