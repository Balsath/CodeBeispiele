/**
 * 
 */
/**
 * @author Tim
 *
 */
package dee.hhn.seb.gvs.packmoctezuma.chat.mock;